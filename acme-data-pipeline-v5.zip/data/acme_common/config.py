"""Environment-driven configuration.

All settings come from environment variables so the same code runs locally
(IS_LOCAL=true) and on EKS (IS_LOCAL=false) without edits. The workshop
injects IS_LOCAL and POSTGRES_* automatically; the rest have sensible
local defaults.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from datetime import date, datetime, timezone


def _env_bool(name: str, default: bool) -> bool:
    raw = os.getenv(name)
    if raw is None or raw == "":
        return default
    return raw.strip().lower() in {"1", "true", "yes", "y"}


def _env_str(name: str, default: str = "") -> str:
    val = os.getenv(name)
    return default if val is None or val == "" else val


@dataclass(frozen=True)
class Settings:
    """Immutable snapshot of the runtime configuration."""

    # --- environment -------------------------------------------------------
    is_local: bool = field(default_factory=lambda: _env_bool("IS_LOCAL", True))
    run_date: date = field(
        default_factory=lambda: datetime.strptime(
            _env_str("RUN_DATE", date.today().isoformat()), "%Y-%m-%d"
        ).date()
    )
    run_id: str = field(
        default_factory=lambda: _env_str(
            "RUN_ID", datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        )
    )
    log_level: str = field(default_factory=lambda: _env_str("LOG_LEVEL", "INFO"))

    # --- PostgreSQL (injected by the workshop) ------------------------------
    postgres_host: str = field(default_factory=lambda: _env_str("POSTGRES_HOST", "localhost"))
    postgres_port: int = field(default_factory=lambda: int(_env_str("POSTGRES_PORT", "5432")))
    postgres_name: str = field(default_factory=lambda: _env_str("POSTGRES_NAME", "postgres"))
    postgres_user: str = field(default_factory=lambda: _env_str("POSTGRES_USER", "postgres"))
    postgres_pass: str = field(default_factory=lambda: _env_str("POSTGRES_PASS", ""))
    source_schema: str = field(default_factory=lambda: _env_str("SOURCE_SCHEMA", "public"))
    analytics_schema: str = field(default_factory=lambda: _env_str("ANALYTICS_SCHEMA", "analytics"))
    metadata_schema: str = field(default_factory=lambda: _env_str("METADATA_SCHEMA", "metadata"))

    # --- Lake (S3 in cloud, local folder when IS_LOCAL) --------------------
    s3_bucket: str = field(default_factory=lambda: _env_str("S3_BUCKET", ""))
    lake_prefix: str = field(default_factory=lambda: _env_str("LAKE_PREFIX", "lake"))
    local_lake_dir: str = field(default_factory=lambda: _env_str("LOCAL_LAKE_DIR", "./lake"))
    s3_endpoint_url: str = field(default_factory=lambda: _env_str("S3_ENDPOINT_URL", ""))

    # --- Source data --------------------------------------------------------
    # BRONZE_SOURCE: "postgres" (default, the HRIS source system) or "csv"
    # (read the sample CSVs directly; handy before Postgres is seeded).
    bronze_source: str = field(default_factory=lambda: _env_str("BRONZE_SOURCE", "postgres"))
    sample_data_dir: str = field(
        default_factory=lambda: _env_str(
            "SAMPLE_DATA_DIR",
            "../sampleData/data-engineering-sample-performance-scenario/"
            "data-engineering-performance-talent-management",
        )
    )
    # Root of the learning_activity/year=.../events-*.jsonl tree (local path
    # or s3://bucket/prefix). Defaults to the sample data folder locally.
    learning_activity_dir: str = field(default_factory=lambda: _env_str("LEARNING_ACTIVITY_DIR", ""))

    # --- Behaviour ----------------------------------------------------------
    fail_on_empty: bool = field(default_factory=lambda: _env_bool("FAIL_ON_EMPTY", True))
    write_gold_to_postgres: bool = field(
        default_factory=lambda: _env_bool("WRITE_GOLD_TO_POSTGRES", True)
    )
    lineage_backend: str = field(default_factory=lambda: _env_str("LINEAGE_BACKEND", "auto"))
    # Business rule (mentor decision): a skill gap is "critical" when
    # required_level - proficiency_level >= this threshold, regardless of
    # competency category or job level. Default 2; override per run.
    skill_gap_critical_threshold: int = field(
        default_factory=lambda: int(_env_str("SKILL_GAP_CRITICAL_THRESHOLD", "2"))
    )

    # --- Derived ------------------------------------------------------------
    @property
    def lake_root(self) -> str:
        """Root URI of the medallion lake: s3://bucket/prefix or a local dir."""
        if self.is_local and not self.s3_bucket:
            return self.local_lake_dir.rstrip("/")
        return f"s3://{self.s3_bucket}/{self.lake_prefix.strip('/')}"

    @property
    def learning_activity_root(self) -> str:
        if self.learning_activity_dir:
            return self.learning_activity_dir.rstrip("/")
        return f"{self.sample_data_dir.rstrip('/')}/learning_activity"

    @property
    def sslmode(self) -> str:
        return "prefer" if self.is_local else "require"

    def partition(self, run_date: date | None = None) -> str:
        """Hive-style partition path for a run date: year=YYYY/month=MM/day=DD."""
        d = run_date or self.run_date
        return f"year={d:%Y}/month={d:%m}/day={d:%d}"


SOURCE_TABLES: tuple[str, ...] = (
    "teams",
    "competencies",
    "employees",
    "projects",
    "performance_reviews",
    "competency_assessments",
    "talent_review",
)


def get_settings() -> Settings:
    return Settings()
