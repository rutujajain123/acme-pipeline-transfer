"""Gold transforms: Silver -> analytics marts, one per business question.

Grain and lineage for each mart are documented in the function docstrings
and reproduced in data/README.md (source-to-target mapping).

Business question -> mart
  1. ratings & review history          -> fact_performance_review  (employee x review_period)
  2. critical skill gaps                -> mart_skill_gap           (employee x competency)
  3. high-potential / promotion-ready   -> mart_talent_matrix       (employee)
  4. training completed                 -> fact_learning_summary    (employee)
  5. attrition risk                     -> mart_attrition_risk      (employee)
  6. performance vs team/project        -> mart_team_performance    (team)
  7. skill distribution                 -> mart_skill_inventory     (department x competency x level)
"""
from __future__ import annotations

import pandas as pd

POTENTIAL_SCORE = {"Low": 1, "Medium": 2, "High": 3}
RISK_SCORE = {"Low": 1, "Medium": 2, "High": 3}
READINESS_SCORE = {"Not Ready": 1, "1-2 Years": 2, "Ready Now": 3}


def dim_employee(employees: pd.DataFrame, teams: pd.DataFrame) -> pd.DataFrame:
    """One row per employee with team/department denormalised."""
    t = teams.rename(columns={"name": "team_name"})[["team_id", "team_name", "department"]]
    out = employees.merge(t, on="team_id", how="left")
    cols = ["employee_id", "full_name", "email", "job_level", "hire_date", "tenure_years", "team_id", "team_name", "department"]
    return out[cols].sort_values("employee_id").reset_index(drop=True)


def fact_performance_review(reviews: pd.DataFrame, dim_emp: pd.DataFrame) -> pd.DataFrame:
    """Grain: employee x review_period. Adds prior rating, delta and trend.

    Lineage: silver.performance_reviews.rating -> rating; prior_rating via
    lag over period_order per employee; rating_delta = rating - prior_rating.
    """
    r = reviews.sort_values(["employee_id", "period_order"]).copy()
    r["prior_rating"] = r.groupby("employee_id")["rating"].shift(1)
    r["rating_delta"] = r["rating"] - r["prior_rating"]
    r["trend"] = pd.cut(r["rating_delta"].fillna(0), bins=[-10, -0.5, 0.5, 10], labels=["declining", "stable", "improving"]).astype(str)
    r.loc[r["prior_rating"].isna(), "trend"] = "first_review"
    r["prior_rating"] = r["prior_rating"].astype("Int64")
    r["rating_delta"] = r["rating_delta"].astype("Int64")
    out = r.merge(dim_emp[["employee_id", "full_name", "job_level", "team_name", "department"]], on="employee_id", how="left")
    cols = ["review_id", "employee_id", "full_name", "job_level", "team_name", "department", "review_period", "review_year", "review_half", "rating", "prior_rating", "rating_delta", "trend", "submitted_date", "manager_comment"]
    return out[cols].reset_index(drop=True)


GAP_SEVERITY = {0: "none", 1: "minor", 2: "moderate", 3: "major", 4: "severe"}
DEFAULT_GAP_THRESHOLD = 2


def gap_severity(gap: pd.Series) -> pd.Series:
    """Label each gap level 0-4 (required - proficiency, clipped at 0)."""
    return gap.clip(lower=0, upper=4).astype(int).map(GAP_SEVERITY)


def mart_skill_gap(
    assessments: pd.DataFrame,
    competencies: pd.DataFrame,
    dim_emp: pd.DataFrame,
    critical_threshold: int = DEFAULT_GAP_THRESHOLD,
) -> pd.DataFrame:
    """Grain: employee x competency (latest assessment).

    gap = required_level - proficiency_level when positive (0..4).
    gap_severity = none/minor/moderate/major/severe for gap 0..4.
    critical_gap = gap >= critical_threshold (default 2, env
    SKILL_GAP_CRITICAL_THRESHOLD). Business rule agreed with the mentor:
    all competency categories are treated equally - a Leadership gap of 3
    and a Technical gap of 3 are equally critical. Consumers can re-filter
    on `gap` with their own threshold.
    """
    a = assessments.sort_values("assessed_date").drop_duplicates(["employee_id", "competency_id"], keep="last")
    c = competencies.rename(columns={"name": "competency_name"})[["competency_id", "competency_name", "category"]]
    out = a.merge(c, on="competency_id", how="left").merge(
        dim_emp[["employee_id", "full_name", "job_level", "team_name", "department"]], on="employee_id", how="left"
    )
    out["gap_severity"] = gap_severity(out["gap"])
    out["critical_gap"] = out["gap"] >= int(critical_threshold)
    out["critical_threshold"] = int(critical_threshold)
    cols = ["employee_id", "full_name", "job_level", "team_name", "department", "competency_id", "competency_name", "category", "proficiency_level", "required_level", "gap", "gap_status", "gap_severity", "critical_gap", "critical_threshold", "assessed_date"]
    return out[cols].sort_values(["employee_id", "competency_id"]).reset_index(drop=True)


def mart_talent_matrix(fact_reviews: pd.DataFrame, talent: pd.DataFrame, skill_gap: pd.DataFrame, dim_emp: pd.DataFrame) -> pd.DataFrame:
    """Grain: employee. 9-box = performance (avg of last two ratings) x potential.

    performance_band: <2.5 low, <3.75 medium, else high. potential from talent_review.
    high_potential = potential_rating == High; promotion_ready = Ready Now.
    """
    last2 = (
        fact_reviews.sort_values(["employee_id", "review_year", "review_half"])
        .groupby("employee_id")
        .tail(2)
        .groupby("employee_id")
        .agg(avg_recent_rating=("rating", "mean"), latest_rating=("rating", "last"), latest_trend=("trend", "last"), reviews_count=("rating", "size"))
        .reset_index()
    )
    gaps = skill_gap.groupby("employee_id").agg(open_gaps=("gap", lambda s: int((s > 0).sum())), critical_gaps=("critical_gap", "sum")).reset_index()
    out = dim_emp.merge(last2, on="employee_id", how="left").merge(talent, on="employee_id", how="left").merge(gaps, on="employee_id", how="left")
    out["open_gaps"] = out["open_gaps"].fillna(0).astype(int)
    out["critical_gaps"] = out["critical_gaps"].fillna(0).astype(int)
    out["performance_band"] = pd.cut(out["avg_recent_rating"], bins=[0, 2.5, 3.75, 5.01], labels=["low", "medium", "high"], right=False).astype(str)
    out["potential_score"] = out["potential_rating"].map(POTENTIAL_SCORE)
    out["nine_box"] = out["performance_band"].str.capitalize() + " performance / " + out["potential_rating"].astype(str) + " potential"
    out["high_potential"] = out["potential_rating"] == "High"
    out["promotion_ready"] = out["promotion_readiness"] == "Ready Now"
    out["ready_and_high_perf"] = out["promotion_ready"] & (out["performance_band"] == "high")
    cols = ["employee_id", "full_name", "job_level", "team_id", "team_name", "department", "tenure_years", "avg_recent_rating", "latest_rating", "latest_trend", "performance_band", "potential_rating", "potential_score", "promotion_readiness", "nine_box", "high_potential", "promotion_ready", "ready_and_high_perf", "open_gaps", "critical_gaps", "review_cycle"]
    return out[cols].reset_index(drop=True)


def fact_learning_summary(learning: pd.DataFrame, dim_emp: pd.DataFrame) -> pd.DataFrame:
    """Grain: employee. Aggregates the valid learning events per employee."""
    ev = learning.copy()
    pivot = ev.pivot_table(index="employee_id", columns="event_type", values="event_id", aggfunc="count", fill_value=0)
    pivot.columns = [str(c) for c in pivot.columns]
    for c in ["enrollment", "module_started", "module_completed", "course_completed", "quiz_attempted", "quiz_passed", "certification_earned"]:
        if c not in pivot.columns:
            pivot[c] = 0
    agg = ev.groupby("employee_id").agg(
        total_events=("event_id", "count"),
        distinct_courses=("course_name", "nunique"),
        avg_quiz_score=("score", "mean"),
        first_activity=("event_date", "min"),
        last_activity=("event_date", "max"),
    )
    out = dim_emp[["employee_id", "full_name", "job_level", "team_name", "department"]].merge(pivot, on="employee_id", how="left").merge(agg, on="employee_id", how="left")
    count_cols = ["total_events", "enrollment", "module_started", "module_completed", "course_completed", "quiz_attempted", "quiz_passed", "certification_earned", "distinct_courses"]
    for c in count_cols:
        out[c] = out[c].fillna(0).astype(int)
    out["quiz_pass_rate"] = (out["quiz_passed"] / out["quiz_attempted"].replace(0, pd.NA)).astype("Float64").round(3)
    out["course_completion_rate"] = (out["course_completed"] / out["enrollment"].replace(0, pd.NA)).astype("Float64").round(3)
    out["avg_quiz_score"] = out["avg_quiz_score"].astype("Float64").round(1)
    return out.reset_index(drop=True)


def mart_attrition_risk(talent_matrix: pd.DataFrame, learning_summary: pd.DataFrame, talent: pd.DataFrame, as_of: pd.Timestamp | None = None) -> pd.DataFrame:
    """Grain: employee. Combines HR's declared attrition_risk with observed signals.

    risk_score (0-10):
      +3 declared attrition_risk High (+1 Medium)
      +2 latest_trend declining, +1 latest_rating <= 2
      +2 no learning activity in last 365 days (or never)
      +1 Not Ready & >4y tenure (stalled), +1 potential High but not promotion ready (flight risk)
    risk_level: >=6 High, >=3 Medium, else Low.
    """
    as_of = as_of or pd.Timestamp.today().normalize()
    out = talent_matrix.merge(learning_summary[["employee_id", "last_activity", "total_events"]], on="employee_id", how="left")
    out = out.merge(talent[["employee_id", "attrition_risk"]], on="employee_id", how="left")
    score = out["attrition_risk"].map(RISK_SCORE).fillna(0).replace({1: 0, 2: 1, 3: 3})
    score = score + (out["latest_trend"] == "declining") * 2 + (out["latest_rating"].fillna(5) <= 2) * 1
    last = pd.to_datetime(out["last_activity"])
    inactive = last.isna() | ((as_of - last).dt.days > 365)
    score = score + inactive * 2
    score = score + ((out["promotion_readiness"] == "Not Ready") & (out["tenure_years"] > 4)) * 1
    score = score + (out["high_potential"] & ~out["promotion_ready"]) * 1
    out["risk_score"] = score.astype(int)
    out["risk_level"] = pd.cut(out["risk_score"], bins=[-1, 2, 5, 100], labels=["Low", "Medium", "High"]).astype(str)
    out["inactive_learner"] = inactive
    out["days_since_learning"] = (as_of - last).dt.days.astype("Int64")
    cols = ["employee_id", "full_name", "job_level", "team_name", "department", "tenure_years", "latest_rating", "latest_trend", "potential_rating", "promotion_readiness", "attrition_risk", "inactive_learner", "days_since_learning", "risk_score", "risk_level"]
    return out[cols].sort_values(["risk_score", "employee_id"], ascending=[False, True]).reset_index(drop=True)


def mart_team_performance(fact_reviews: pd.DataFrame, projects: pd.DataFrame, teams: pd.DataFrame, talent_matrix: pd.DataFrame) -> pd.DataFrame:
    """Grain: team. Avg rating by period, headcount, talent mix, and project outcomes."""
    latest_period = fact_reviews["review_period"].max()
    rev =fact_reviews.merge(talent_matrix[["employee_id", "team_id"]], on="employee_id", how="left")
    perf = rev.groupby("team_id").agg(
        avg_rating_all=("rating", "mean"),
        reviews=("rating", "size"),
    ).reset_index()
    latest = rev[rev["review_period"] == latest_period].groupby("team_id").agg(avg_rating_latest=("rating", "mean"), declining_share=("trend", lambda s: float((s == "declining").mean()))).reset_index()
    tal = talent_matrix.groupby("team_id").agg(headcount=("employee_id", "size"), high_potential_count=("high_potential", "sum"), promotion_ready_count=("promotion_ready", "sum"), avg_tenure=("tenure_years", "mean")).reset_index()
    proj = projects.groupby("team_id").agg(projects=("project_id", "size"), avg_outcome_score=("outcome_score", "mean"), on_time_share=("outcome_status", lambda s: float((s == "on-time").mean()))).reset_index()
    t = teams.rename(columns={"name": "team_name"})[["team_id", "team_name", "department"]]
    out = t.merge(tal, on="team_id", how="left").merge(perf, on="team_id", how="left").merge(latest, on="team_id", how="left").merge(proj, on="team_id", how="left")
    for c in ["headcount", "high_potential_count", "promotion_ready_count", "reviews", "projects"]:
        out[c] = out[c].fillna(0).astype(int)
    for c in ["avg_rating_all", "avg_rating_latest", "avg_tenure", "avg_outcome_score", "on_time_share", "declining_share"]:
        out[c] = out[c].astype("Float64").round(3)
    out["latest_period"] = latest_period
    return out.sort_values("team_id").reset_index(drop=True)


def mart_skill_inventory(skill_gap: pd.DataFrame) -> pd.DataFrame:
    """Grain: department x competency x proficiency_level -> employee counts + gap share."""
    g = skill_gap.groupby(["department", "category", "competency_id", "competency_name", "proficiency_level"]).agg(
        employees=("employee_id", "nunique"),
        with_gap=("gap", lambda s: int((s > 0).sum())),
        critical=("critical_gap", "sum"),
        avg_gap=("gap", "mean"),
    ).reset_index()
    g["critical"] = g["critical"].astype(int)
    g["avg_gap"] = g["avg_gap"].astype(float).round(3)
    return g.sort_values(["department", "competency_id", "proficiency_level"]).reset_index(drop=True)


GOLD_KEYS: dict[str, list[str]] = {
    "dim_employee": ["employee_id"],
    "fact_performance_review": ["review_id"],
    "mart_skill_gap": ["employee_id", "competency_id"],
    "mart_talent_matrix": ["employee_id"],
    "fact_learning_summary": ["employee_id"],
    "mart_attrition_risk": ["employee_id"],
    "mart_team_performance": ["team_id"],
    "mart_skill_inventory": ["department", "competency_id", "proficiency_level"],
}
