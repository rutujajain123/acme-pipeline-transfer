"""Layer job implementations. Each `run_*` is importable (for tests and the
daily orchestrator) and wrapped by a thin data/<job-name>/job.py entrypoint.
"""
from __future__ import annotations

import logging
import os
from datetime import datetime, timezone

import pandas as pd

from . import storage
from .config import SOURCE_TABLES, Settings
from .lineage import Run
from .transforms import bronze as tb
from .transforms import gold as tg
from .transforms import silver as ts
from .validation import PRIMARY_KEYS, SchemaDriftError, validate_dataset

log = logging.getLogger("acme.jobs")


# --------------------------------------------------------------------------- #
# helpers
# --------------------------------------------------------------------------- #
def _bronze_dir(s: Settings, table: str) -> str:
    return storage.join(s.lake_root, "bronze", table, s.partition())


def _silver_dir(s: Settings, table: str) -> str:
    return storage.join(s.lake_root, "silver", table, s.partition())


def _quarantine_dir(s: Settings, table: str) -> str:
    return storage.join(s.lake_root, "silver", "_quarantine", table, s.partition())


def _gold_dir(s: Settings, table: str) -> str:
    return storage.join(s.lake_root, "gold", table)


def _guard_empty(s: Settings, run: Run, name: str, n: int) -> None:
    if n == 0:
        run.validation(name, "non_empty_output", False, 0, "zero rows written")
        if s.fail_on_empty:
            raise RuntimeError(f"{name}: zero rows written (FAIL_ON_EMPTY=true)")
        log.warning("%s: zero rows written", name)


# --------------------------------------------------------------------------- #
# BRONZE
# --------------------------------------------------------------------------- #
def _read_source_table(s: Settings, table: str) -> tuple[pd.DataFrame, str, str]:
    if s.bronze_source == "csv":
        # CSV exports from a local folder or an S3 landing prefix (s3://bucket/prefix)
        path = storage.join(s.sample_data_dir, f"{table}.csv")
        if storage.is_s3(path):
            import io

            df = pd.read_csv(io.BytesIO(storage.read_bytes(path)), dtype=str, keep_default_na=False)
        else:
            df = pd.read_csv(path, dtype=str, keep_default_na=False)
        return df, "csv", path
    from . import postgres

    return postgres.read_table(s, table), "postgres", f"{s.source_schema}.{table}"


def run_bronze(s: Settings) -> dict[str, int]:
    """Ingest the 7 relational tables + learning_activity JSONL into Bronze."""
    counts: dict[str, int] = {}
    ingest_ts = datetime.now(timezone.utc)
    with Run(s, "acme-bronze-ingest", "bronze") as run:
        for table in SOURCE_TABLES:
            df, source, src_path = _read_source_table(s, table)
            out = tb.add_ingest_metadata(df, s.run_id, source, src_path, ingest_ts)
            dest = _bronze_dir(s, table)
            manifest = {"source": source, "source_path": src_path, "source_rows": int(len(df))}
            if source == "csv":
                manifest["source_bytes"] = storage.size_bytes(src_path)
            storage.write_partition(out, dest, manifest)
            run.dataset(f"bronze.{table}", dest, rows_read=len(df), rows_processed=len(out), rows_written=len(out))
            run.edge(f"{source}.{table}", f"bronze.{table}", "add_ingest_metadata")
            run.validation(f"bronze.{table}", "row_count_matches_source", len(out) == len(df), abs(len(out) - len(df)))
            _guard_empty(s, run, f"bronze.{table}", len(out))
            counts[table] = len(out)

        # learning activity: 783 partitioned JSONL files, keep source partitions
        files = storage.list_files(s.learning_activity_root, ".jsonl")
        events: list[dict] = []
        malformed: list[dict] = []
        total_bytes = 0
        for f in files:
            ev, bad = tb.parse_jsonl_lines(storage.iter_jsonl_lines(f), f)
            part = tb.partition_from_path(f)
            for row in ev:
                row.update(part)
            for row in bad:
                row.update(part)
            events.extend(ev)
            malformed.extend(bad)
            total_bytes += storage.size_bytes(f)
        ev_df = pd.DataFrame(events)
        bad_df = pd.DataFrame(malformed)
        if ev_df.empty:
            raise RuntimeError(f"no learning events found under {s.learning_activity_root}")
        ev_df = tb.add_ingest_metadata(ev_df, s.run_id, "jsonl", s.learning_activity_root, ingest_ts)
        dest = _bronze_dir(s, "learning_activity")
        storage.write_partition(ev_df, dest, {"files": len(files), "source_bytes": total_bytes, "malformed_lines": len(bad_df)})
        if not bad_df.empty:
            qdest = storage.join(s.lake_root, "bronze", "_malformed", "learning_activity", s.partition())
            storage.write_partition(tb.add_ingest_metadata(bad_df, s.run_id, "jsonl", s.learning_activity_root, ingest_ts), qdest)
        run.dataset("bronze.learning_activity", dest, rows_read=len(ev_df) + len(bad_df), rows_processed=len(ev_df), rows_written=len(ev_df), rows_quarantined=len(bad_df))
        run.edge("jsonl.learning_activity", "bronze.learning_activity", "parse_jsonl_lines")
        run.validation("bronze.learning_activity", "malformed_json_lines", len(bad_df) == 0, len(bad_df), f"{len(bad_df)} malformed lines preserved in bronze/_malformed")
        run.validation("bronze.learning_activity", "partition_keys_present", bool({"year", "month", "day"} <= set(ev_df.columns)))
        _guard_empty(s, run, "bronze.learning_activity", len(ev_df))
        counts["learning_activity"] = len(ev_df)
        counts["learning_activity_malformed"] = len(bad_df)
    return counts


# --------------------------------------------------------------------------- #
# SILVER
# --------------------------------------------------------------------------- #
SILVER_ORDER = ("teams", "competencies", "employees", "projects", "performance_reviews", "competency_assessments", "talent_review", "learning_activity")


def run_silver(s: Settings) -> dict[str, int]:
    """Validate (Pydantic), dedupe, enforce FKs, enrich; quarantine failures."""
    counts: dict[str, int] = {}
    parents: dict[str, pd.DataFrame] = {}
    with Run(s, "acme-silver-transform", "silver") as run:
        for table in SILVER_ORDER:
            src = _bronze_dir(s, table)
            raw = storage.read_table(src)
            if raw.empty:
                raise RuntimeError(f"bronze.{table} is empty or missing at {src}")
            prepared = ts.prepare_learning_events(raw) if table == "learning_activity" else ts.normalise_bronze(raw)
            try:
                valid, quarantine, summary = validate_dataset(prepared, table, parents=parents)
            except SchemaDriftError as exc:
                run.validation(f"silver.{table}", "schema_drift", False, len(raw), str(exc))
                raise
            if table in ts.ENRICHERS:
                valid = ts.ENRICHERS[table](valid)
            dest = _silver_dir(s, table)
            storage.write_partition(valid, dest)
            if not quarantine.empty:
                quarantine = quarantine.astype("string")
                storage.write_partition(quarantine, _quarantine_dir(s, table))
            for chk in summary.checks:
                run.validation(f"silver.{table}", chk["check"], chk["passed"], chk["failed_rows"], chk["message"])
            dupes = next((c["failed_rows"] for c in summary.checks if c["check"] == "unique_primary_key"), 0)
            reconciled = len(raw) == len(valid) + len(quarantine) + dupes
            run.validation(f"silver.{table}", "reconciliation_bronze_eq_valid_plus_quarantine_plus_dupes", reconciled, 0 if reconciled else abs(len(raw) - len(valid) - len(quarantine) - dupes))
            run.dataset(f"silver.{table}", dest, rows_read=len(raw), rows_processed=summary.rows_in, rows_written=len(valid), rows_quarantined=len(quarantine))
            run.edge(f"bronze.{table}", f"silver.{table}", f"validate_dataset+{ts.ENRICHERS[table].__name__ if table in ts.ENRICHERS else 'normalise_bronze'}")
            _guard_empty(s, run, f"silver.{table}", len(valid))
            parents[table] = valid
            counts[table] = len(valid)
            counts[f"{table}_quarantined"] = len(quarantine)
    return counts


# --------------------------------------------------------------------------- #
# GOLD
# --------------------------------------------------------------------------- #
def _read_silver(s: Settings, table: str) -> pd.DataFrame:
    df = storage.read_table(_silver_dir(s, table))
    if df.empty:
        raise RuntimeError(f"silver.{table} is empty for {s.partition()}")
    # parquet keeps dtypes; csv fallback needs dates re-parsed
    for c in ("hire_date", "submitted_date", "assessed_date", "event_date"):
        if c in df.columns:
            df[c] = pd.to_datetime(df[c])
    return df


def build_gold(silver: dict[str, pd.DataFrame], gap_threshold: int = tg.DEFAULT_GAP_THRESHOLD) -> dict[str, pd.DataFrame]:
    """Pure function: all Silver frames -> all Gold frames (used by tests)."""
    dim_emp = tg.dim_employee(silver["employees"], silver["teams"])
    fact_rev = tg.fact_performance_review(silver["performance_reviews"], dim_emp)
    gap = tg.mart_skill_gap(silver["competency_assessments"], silver["competencies"], dim_emp, gap_threshold)
    talent = tg.mart_talent_matrix(fact_rev, silver["talent_review"], gap, dim_emp)
    learn = tg.fact_learning_summary(silver["learning_activity"], dim_emp)
    risk = tg.mart_attrition_risk(talent, learn, silver["talent_review"])
    team = tg.mart_team_performance(fact_rev, silver["projects"], silver["teams"], talent)
    inv = tg.mart_skill_inventory(gap)
    return {
        "dim_employee": dim_emp,
        "fact_performance_review": fact_rev,
        "mart_skill_gap": gap,
        "mart_talent_matrix": talent,
        "fact_learning_summary": learn,
        "mart_attrition_risk": risk,
        "mart_team_performance": team,
        "mart_skill_inventory": inv,
    }


GOLD_INPUTS = {
    "dim_employee": ["employees", "teams"],
    "fact_performance_review": ["performance_reviews", "employees"],
    "mart_skill_gap": ["competency_assessments", "competencies", "employees"],
    "mart_talent_matrix": ["performance_reviews", "talent_review", "competency_assessments", "employees"],
    "fact_learning_summary": ["learning_activity", "employees"],
    "mart_attrition_risk": ["performance_reviews", "talent_review", "learning_activity", "employees"],
    "mart_team_performance": ["performance_reviews", "projects", "teams", "talent_review"],
    "mart_skill_inventory": ["competency_assessments", "competencies", "employees"],
}


def run_gold(s: Settings) -> dict[str, int]:
    counts: dict[str, int] = {}
    with Run(s, "acme-gold-analytics", "gold") as run:
        silver = {t: _read_silver(s, t) for t in SILVER_ORDER}
        gold = build_gold(silver, s.skill_gap_critical_threshold)
        log.info("skill gap critical threshold = %d", s.skill_gap_critical_threshold)
        # reconciliation checks (Silver -> Gold)
        run.validation("gold.dim_employee", "rowcount_eq_silver_employees", len(gold["dim_employee"]) == len(silver["employees"]), abs(len(gold["dim_employee"]) - len(silver["employees"])))
        run.validation("gold.fact_performance_review", "rowcount_eq_silver_reviews", len(gold["fact_performance_review"]) == len(silver["performance_reviews"]), abs(len(gold["fact_performance_review"]) - len(silver["performance_reviews"])))
        run.validation("gold.mart_talent_matrix", "one_row_per_employee", gold["mart_talent_matrix"]["employee_id"].is_unique)
        run.validation("gold.fact_learning_summary", "events_sum_eq_silver", int(gold["fact_learning_summary"]["total_events"].sum()) == len(silver["learning_activity"]))
        avg_check = abs(gold["fact_performance_review"]["rating"].mean() - silver["performance_reviews"]["rating"].mean()) < 1e-9
        run.validation("gold.fact_performance_review", "avg_rating_matches_silver", bool(avg_check))

        write_pg = s.write_gold_to_postgres and run.backend == "postgres"
        if s.write_gold_to_postgres and not write_pg:
            log.warning("postgres unreachable: gold written to lake only")
        for name, df in gold.items():
            dest = _gold_dir(s, name)
            storage.write_partition(df, dest, {"run_id": s.run_id, "run_date": s.run_date.isoformat(), "keys": tg.GOLD_KEYS[name]})
            if write_pg:
                from . import postgres

                postgres.upsert_dataframe(s, _pg_ready(df), name, tg.GOLD_KEYS[name])
            run.dataset(f"gold.{name}", dest, rows_read=sum(len(silver[t]) for t in GOLD_INPUTS[name]), rows_processed=len(df), rows_written=len(df))
            for t in GOLD_INPUTS[name]:
                run.edge(f"silver.{t}", f"gold.{name}", name)
            _guard_empty(s, run, f"gold.{name}", len(df))
            counts[name] = len(df)
    return counts


def _pg_ready(df: pd.DataFrame) -> pd.DataFrame:
    """Make a frame driver-friendly: object dates -> str, nullable ints -> object."""
    out = df.copy()
    for c in out.columns:
        kind = str(out[c].dtype)
        if kind == "object" or pd.api.types.is_string_dtype(out[c]):
            out[c] = out[c].astype(object).where(out[c].notna(), None)
        elif kind in {"Int64", "Float64", "boolean"}:
            out[c] = out[c].astype(object).where(out[c].notna(), None)
        elif "date" in kind and "datetime" not in kind:
            out[c] = out[c].astype(str)
    return out


def run_all(s: Settings) -> dict[str, dict[str, int]]:
    return {"bronze": run_bronze(s), "silver": run_silver(s), "gold": run_gold(s)}
