# ACME Performance & Talent Analytics Pipeline

Batch ETL on a medallion data lake (Bronze → Silver → Gold) that answers ACME's
seven workforce questions from a PostgreSQL HRIS source and an S3 learning-activity
event stream. Python/Pandas jobs, Pydantic schema contracts, quarantine for bad
rows, lineage + validation tracking in PostgreSQL, and Jupyter for insights.

```
PostgreSQL (HRIS)  ─┐                                               ┌─ analytics schema (PostgreSQL)
  7 tables           ├─► BRONZE ──► SILVER ──► GOLD (8 marts) ──────┤
S3 learning_activity ┘   raw +      typed,     one table per        └─ gold/ parquet on the lake
  783 JSONL files        metadata   validated, business question              │
                            │       quarantine                               ▼
                            └───── metadata schema: runs, datasets, edges, validations ──► notebooks
```

## Layout

| Path | Purpose |
|---|---|
| `acme_common/` | Shared package: `config` (env vars), `log` (JSON logs), `retry` (backoff), `storage` (local/S3 lake), `postgres`, `lineage`, `validation/` (Pydantic contracts), `transforms/` (pure functions), `jobs` (layer runners) |
| `acme-bronze-ingest/`, `acme-silver-transform/`, `acme-gold-analytics/` | One `job.py` per layer (workshop `python-job` convention) |
| `acme-daily-etl/` | Runs all three layers in order — the job deployed to EKS |
| `sql/metadata_schema.sql` | Lineage/observability tables and views |
| `tests/` | unit, e2e (smoke + idempotency), integration (Postgres/S3), synthetic fixture generator |
| `notebooks/` | `01_profiling`, `02_business_questions`, `03_lineage_and_quality` |
| `bin/` | `seed-sources.sh`, `run-pipeline.sh`, `run-tests.sh`, `perf-test.sh` |

## Quick start (local)

```bash
cd data
pip install -r requirements.txt

# 1. Seed the source systems (uses the dataset's own load.sh + creates metadata/analytics schemas)
export POSTGRES_HOST=localhost POSTGRES_PORT=5432 POSTGRES_NAME=postgres POSTGRES_USER=postgres POSTGRES_PASS=postgres
bin/seed-sources.sh

# 2. Run the pipeline (Bronze -> Silver -> Gold) into ./lake
bin/run-pipeline.sh                     # or --layer bronze|silver|gold, --date YYYY-MM-DD

# No database yet? Run end-to-end on the CSVs with lineage written to the lake:
BRONZE_SOURCE=csv LINEAGE_BACKEND=file WRITE_GOLD_TO_POSTGRES=false bin/run-pipeline.sh
# No dataset at all? Synthetic data with the same quirks:
bin/run-pipeline.sh --synthetic

# 3. Explore
jupyter lab notebooks/
```

## Cloud (EKS)

```bash
echo "export TF_VAR_aws_eks_enabled=true" >> ~/.bashrc && source ~/.bashrc
export S3_BUCKET=<lake bucket from infra outputs>   # LEARNING_ACTIVITY_DIR=s3://.../landing/learning_activity
bin/seed-sources.sh                                 # loads Aurora + syncs JSONL to S3
bin/run-pipeline.sh --cloud                         # ../bin/deploy-backend.sh + kubectl logs -f job/acme-daily-etl
```

`IS_LOCAL`, `POSTGRES_*` are injected by the platform. Everything else is read
from environment variables (see `acme_common/config.py`); **no code changes between local and cloud**.

| Variable | Default | Meaning |
|---|---|---|
| `S3_BUCKET` / `LAKE_PREFIX` | – / `lake` | Lake root `s3://bucket/prefix`; when unset and `IS_LOCAL=true`, `LOCAL_LAKE_DIR` (`./lake`) |
| `BRONZE_SOURCE` | `postgres` | `csv` reads `SAMPLE_DATA_DIR/*.csv` instead of the DB |
| `LEARNING_ACTIVITY_DIR` | sample folder | Root of `year=/month=/day=/events-*.jsonl` (local or `s3://`) |
| `RUN_DATE` / `RUN_ID` | today / UTC timestamp | Partition and lineage key |
| `LINEAGE_BACKEND` | `auto` | `postgres` metadata schema, or `file` (`<lake>/_metadata/<run_id>/`) |
| `WRITE_GOLD_TO_POSTGRES` | `true` | Also upsert Gold marts into `ANALYTICS_SCHEMA` (`analytics`) |
| `FAIL_ON_EMPTY` | `true` | Zero rows written halts the pipeline (else WARN) |
| `SKILL_GAP_CRITICAL_THRESHOLD` | `2` | Gap level (required − proficiency) at which a skill gap is flagged critical |
| `PYTHON` | `python3` | Interpreter used by the `bin/*.sh` scripts (e.g. `python3.14`) |

## Medallion contracts

**Bronze** – immutable, as received. Every table → `bronze/<table>/year=YYYY/month=MM/day=DD/part-0.parquet`
+ `_manifest.json` (rows, source path, source bytes). All columns kept as strings plus
`_ingest_ts, _run_id, _source, _source_file`. JSONL keeps its source partitions; malformed
lines are preserved in `bronze/_malformed/learning_activity/…`, never dropped.
Re-running the same `RUN_DATE` overwrites the partition (idempotent).

**Silver** – one Pydantic model per table (`validation/models.py`): required/non-null,
types, ranges (rating 1–5, levels 1–5, score 0–100), enums (departments, job levels,
event types…), formats (`2025-H1`, `EV0000000001`), no future dates. Then dedupe on the
primary key (latest `_ingest_ts` wins), FK anti-joins against parents, and enrichment.
Failures go to `silver/_quarantine/<table>/…` with `error_fields` + `error_reason`.
Missing required columns = schema drift → job fails loudly.

**Gold** – full-refresh snapshot per mart on the lake + `ON CONFLICT … DO UPDATE` upsert in
PostgreSQL. Grain is asserted in `jobs.run_gold` reconciliation checks.

| Business question | Gold table | Grain | Inputs |
|---|---|---|---|
| Ratings & review history | `fact_performance_review` | employee × period | performance_reviews, employees, teams |
| Critical skill gaps | `mart_skill_gap` | employee × competency | competency_assessments, competencies (gap 0–4 → `gap_severity`; `critical_gap` = gap ≥ `SKILL_GAP_CRITICAL_THRESHOLD`, default 2) |
| High-potential / promotion-ready | `mart_talent_matrix` | employee | reviews, talent_review, skill gaps |
| Training completed | `fact_learning_summary` | employee | learning_activity |
| Attrition risk | `mart_attrition_risk` | employee | talent matrix, learning summary, talent_review |
| Performance vs team/project | `mart_team_performance` | team | reviews, projects, teams, talent matrix |
| Skill distribution | `mart_skill_inventory` | department × competency × level | skill gaps |
| (dimension) | `dim_employee` | employee | employees, teams |

### Source-to-target mapping (where columns are renamed, cast or aggregated)

| Source | Bronze | Silver | Gold |
|---|---|---|---|
| `employees.hire_date` (text) | string | `date` + derived `tenure_years`, `full_name`; `email` lower-cased | `dim_employee` |
| `performance_reviews.rating` | string | `int` 1–5; derived `review_year`, `review_half`, `period_order` | `rating`, `prior_rating` (lag), `rating_delta`, `trend` |
| `competency_assessments.*_level` | string | `int` 1–5; derived `gap = max(required−proficiency,0)`, `gap_status` | `critical_gap`, inventory counts |
| `talent_review.*` | string | enums validated | `potential_score`, `nine_box`, `high_potential`, `promotion_ready` |
| `learning_activity.employee_id` (JSON string) | string | cast to `int` (null → quarantine) | per-employee counts, rates |
| `learning_activity.notes` (39 events) | kept in `_extra_json` | mapped to `text` | – |
| `learning_activity.event_date` | string | parsed `datetime` (blank/odd → quarantine) | `last_activity`, `days_since_learning` |
| `learning_activity.score` | string | `Int64` 0–100 | `avg_quiz_score`, `quiz_pass_rate` |
| `projects.outcome_score` | string | `float` | `avg_outcome_score`, `on_time_share` per team |

## Observability & lineage

Every job runs inside `lineage.Run`: start/end time, duration, exit status; per dataset
`rows_read / processed / written / quarantined`; lineage edges (input → output, transformation);
validation results. Written to `metadata.pipeline_runs / dataset_versions / lineage_edges /
validation_results` (or `_metadata/` JSONL on the lake). Logs are one JSON object per line
with `level`, `job`, `run_id`. `03_lineage_and_quality.ipynb` draws the lineage graph.

Error handling: DB/S3 calls retry with exponential backoff (`retry.py`); schema drift and
zero-row outputs fail the run; malformed rows are quarantined with a WARN.

## Testing

```bash
bin/run-tests.sh                              # unit + e2e with coverage (fails under 80%)
RUN_INTEGRATION=true bin/run-tests.sh         # + PostgreSQL/S3 integration tests
bin/perf-test.sh                              # 1x/5x/20x synthetic scale test (wall time, max RSS)
```

Evidence from the synthetic fixture (planted defects: future hire date, rating 9, duplicate
review, orphan assessment, 13 bad learning events, 4 malformed JSONL lines):

```
47 passed, 0 failed, 4 skipped (integration tests need RUN_INTEGRATION=true)
silver.employees               read=61  written=60  quarantined=1
silver.performance_reviews     read=122 written=120 quarantined=1   (+1 duplicate removed)
silver.competency_assessments  read=181 written=180 quarantined=1   (fk violation)
silver.learning_activity       read=247 written=234 quarantined=13  (null employee_id, bad dates)
gold reconciliation: dim_employee == silver.employees; sum(total_events) == silver.learning_activity; avg rating equal
rerun with same RUN_DATE: identical counts, one part file per partition
```
<!-- TODO: replace with the output from the real dataset + kubectl logs screenshot -->

## Business rules (agreed with mentor)

- **Engine:** Pandas (mentor confirmed Pandas or PySpark are both acceptable).
- **Skill gaps:** gap = required − proficiency (0–4), labelled `none / minor / moderate / major / severe`.
  All competency categories are treated equally — a Leadership gap of 3 and a Technical gap of 3 are
  equally critical. `critical_gap` uses a configurable threshold (default **≥ 2**); the business-questions
  notebook lets the reader re-filter with any threshold and colour-codes severity.

## Data-quality findings on the real dataset

| Finding | Count | Handling |
|---|---|---|
| Malformed JSONL lines | 13 | preserved in `bronze/_malformed/learning_activity` |
| Learning events with null `employee_id` | 76 | quarantined (contract) |
| Learning events with blank / non-standard `event_date` | 54 | quarantined (contract) |
| **Exact duplicate learning events by `event_id` (undocumented)** | 152 ids / 304 rows | one kept, drop count in `validation_results.unique_primary_key` |
| 7 relational tables | 0 failures | — |

Run on real data (local Postgres + LocalStack S3): bronze 12.1 s, silver 1.6 s, gold 2.0 s;
Gold = 2000 employees, 4000 reviews, 4000 skill-gap rows, 100 teams.

## Trade-offs, assumptions, limitations

- **Pandas, not Spark.** The dataset (≈40k rows) fits in memory; Pandas is the workshop's
  recommended toolset and keeps the jobs testable. `storage`/`postgres` are the only IO
  seams, so a PySpark port would replace `transforms/` and keep the contracts.
- **Row-level Pydantic validation** is O(n) Python; fine at this scale, would need
  sampling or vectorised checks beyond ~1M rows.
- **Gold is a full refresh**, not incremental — correct and idempotent, but recomputes everything.
- **Thresholds** (performance bands 2.5/3.75, critical-gap rule, attrition weights) are
  documented assumptions to be tuned with HR.
- Only two review periods and one talent snapshot exist, so trends are single-step.
- Postgres JDBC-style bulk loading uses `execute_batch`; `COPY` would be faster at scale.

## Running the real pipeline on EKS

The workshop Helm chart ships **only** `data/<job>/job.py` and `requirements.txt` into a
Python 3.11 Spark image. `bin/bundle-jobs.sh` therefore generates self-contained `job.py`
files with `acme_common` embedded (base64 zip, extracted at start-up when the package is
not importable) plus cloud defaults (`S3_BUCKET`, `LEARNING_ACTIVITY_DIR`, …) that apply
only when `IS_LOCAL=false`. Locally the same files use the real package.

```bash
# 0. fresh credentials, real AWS (NOT the LocalStack env file)
source ENVIRONMENT.config; unset AWS_ENDPOINT_URL S3_ENDPOINT_URL AWS_PROFILE
export S3_BUCKET=$(terraform -chdir=infra output -raw s3_bucket_name)   # coding-workshop-website-<id>
export LAKE_PREFIX=lake IS_LOCAL=false

# 1. seed Aurora + S3 (POSTGRES_* come from ENVIRONMENT.config)
data/bin/seed-sources.sh                 # RESET_SOURCES=true to drop & reload

# 2. bundle + deploy + watch
data/bin/bundle-jobs.sh                  # regenerates the four job.py files
export TF_VAR_aws_eks_enabled=true && bin/deploy-backend.sh
kubectl wait --for=condition=complete --timeout=20m job/coding-workshop-acme-daily-etl
kubectl logs job/coding-workshop-acme-daily-etl | tail -30

# 3. verify, then scale down
aws s3 ls s3://$S3_BUCKET/lake/ --recursive | awk '{print $4}' | cut -d/ -f2,3 | sort -u
psql "host=$POSTGRES_HOST dbname=$POSTGRES_NAME user=$POSTGRES_USER password=$POSTGRES_PASS sslmode=require" \
     -c "SELECT job_name, status, duration_s FROM metadata.pipeline_runs ORDER BY started_at DESC LIMIT 5;"
export TF_VAR_aws_eks_enabled=false && bin/deploy-backend.sh
```

Known limitation: the four layer jobs are deployed as independent Kubernetes Jobs by the
chart, so `acme-daily-etl` (bronze→silver→gold in one pod) is the one to rely on; the
single-layer jobs may start before their inputs exist and fail on the first attempt.

### Cloud run without Aurora access (S3-only mode)

If the EKS node security group is not allowed into Aurora (pods time out on 5432), bundle
the jobs with `bin/bundle-jobs.sh --source csv`. Bronze then reads the CSV exports from
`s3://<bucket>/lake/landing/source/` (uploaded by `seed-sources.sh`) and the JSONL from
`landing/learning_activity/`; lineage is written to `<lake>/_metadata/` and Gold to `gold/`
on S3. Everything else is identical. `--source postgres` (default) restores the Aurora
source + sink once the security-group rule exists.

## Dashboard (minimal UI)

`bin/dashboard.sh` builds a single static page from the Gold layer and serves it on
http://localhost:8080: six headline tiles, the seven business questions (each linking to
the notebook section), the latest pipeline runs, and two ways into the notebook —
**Open in JupyterLab** (live, with the threshold slider; `JUPYTER_URL`, default
`http://localhost:8889`) and **View notebook** (static HTML export rendered in the page,
no kernel needed). Rebuild after each pipeline run.
