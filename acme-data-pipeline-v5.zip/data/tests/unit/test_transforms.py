"""Core transformation + business-metric tests (target: 95%+ on metric logic)."""
from __future__ import annotations

import json
from datetime import date

import pandas as pd
import pytest

from acme_common.transforms import bronze as tb
from acme_common.transforms import gold as tg
from acme_common.transforms import silver as ts


# --------------------------------------------------------------------------- bronze
def test_parse_jsonl_keeps_malformed_lines_and_extras():
    lines = [(1, '{"event_id":"EV1","employee_id":"5","event_type":"enrollment","notes":"n"}'), (2, '{broken'), (3, ""), (4, "[1,2]")]
    events, bad = tb.parse_jsonl_lines(lines, "f.jsonl")
    assert len(events) == 1 and len(bad) == 2
    assert json.loads(events[0]["_extra_json"]) == {"notes": "n"}
    assert bad[0]["_line_no"] == 2 and "malformed json" in bad[0]["error_reason"]
    assert bad[1]["_line_no"] == 4


def test_partition_from_path():
    assert tb.partition_from_path("s3://b/landing/year=2025/month=03/day=09/events-000.jsonl") == {"year": "2025", "month": "03", "day": "09"}


def test_add_ingest_metadata_casts_to_string_and_tags():
    df = pd.DataFrame({"a": [1, 2]})
    out = tb.add_ingest_metadata(df, "r1", "csv", "a.csv")
    assert str(out["a"].dtype) == "string" and set(out["_run_id"]) == {"r1"} and set(out["_source"]) == {"csv"}


# --------------------------------------------------------------------------- silver
def test_normalise_bronze_nulls_literals_and_strips():
    df = pd.DataFrame({"x": [" a ", "nan", "", "None"], "_run_id": ["r"] * 4})
    out = ts.normalise_bronze(df)
    assert list(out.columns) == ["x"] and out["x"].iloc[0] == "a" and out["x"].isna().sum() == 3


def test_prepare_learning_events_maps_notes_to_text():
    df = pd.DataFrame({"text": [None, "keep"], "_extra_json": ['{"notes":"from notes"}', '{"notes":"ignored"}'], "year": ["2025", "2025"], "month": ["01", "01"], "day": ["02", "02"]})
    out = ts.prepare_learning_events(df)
    assert list(out["text"]) == ["from notes", "keep"] and out["day"].iloc[0] == 2


def test_enrich_assessments_gap_and_status():
    df = pd.DataFrame({"proficiency_level": [1, 3, 5], "required_level": [3, 3, 3]})
    out = ts.enrich_assessments(df)
    assert list(out["gap"]) == [2, 0, 0] and list(out["gap_status"]) == ["gap", "meets", "exceeds"]


def test_enrich_reviews_period_order():
    out = ts.enrich_reviews(pd.DataFrame({"review_period": ["2024-H2", "2025-H1"]}))
    assert list(out["period_order"]) == [2 * 2024 + 2, 2 * 2025 + 1]


def test_enrich_employees_tenure():
    out = ts.enrich_employees(pd.DataFrame({"first_name": ["A"], "last_name": ["B"], "email": ["A@X.CO"], "hire_date": [date(2024, 1, 1)]}), as_of=date(2026, 1, 1))
    assert out["full_name"].item() == "A B" and out["email"].item() == "a@x.co" and abs(out["tenure_years"].item() - 2.0) < 0.01


# --------------------------------------------------------------------------- gold
@pytest.fixture
def mini():
    teams = pd.DataFrame({"team_id": [1, 2], "name": ["T1", "T2"], "department": ["Engineering", "Sales"]})
    employees = pd.DataFrame({"employee_id": [1, 2, 3], "full_name": ["A", "B", "C"], "email": ["a", "b", "c"], "job_level": ["IC1", "Manager", "IC2"], "hire_date": pd.to_datetime(["2020-01-01"] * 3), "tenure_years": [6.0, 6.0, 1.0], "team_id": [1, 1, 2]})
    reviews = ts.enrich_reviews(pd.DataFrame({
        "review_id": [1, 2, 3, 4, 5, 6], "employee_id": [1, 1, 2, 2, 3, 3],
        "review_period": ["2024-H2", "2025-H1"] * 3, "rating": [2, 4, 5, 3, 3, 3],
        "manager_comment": [None] * 6, "submitted_date": pd.to_datetime(["2025-01-15", "2025-07-15"] * 3)}))
    competencies = pd.DataFrame({"competency_id": [1, 2], "name": ["Python", "Coaching"], "category": ["Technical", "Leadership"]})
    assessments = ts.enrich_assessments(pd.DataFrame({"assessment_id": [1, 2, 3], "employee_id": [1, 2, 3], "competency_id": [1, 2, 1], "proficiency_level": [1, 2, 4], "required_level": [3, 3, 3], "assessed_date": pd.to_datetime(["2025-06-01"] * 3)}))
    talent = pd.DataFrame({"employee_id": [1, 2, 3], "review_cycle": ["2025-H1"] * 3, "potential_rating": ["High", "Low", "Medium"], "promotion_readiness": ["Ready Now", "Not Ready", "1-2 Years"], "attrition_risk": ["High", "Low", "Medium"]})
    learning = pd.DataFrame({"event_id": ["EV1", "EV2", "EV3", "EV4"], "employee_id": [1, 1, 2, 2], "event_date": pd.to_datetime(["2026-09-01", "2026-09-02", "2024-01-01", "2024-01-02"]), "event_type": ["quiz_attempted", "quiz_passed", "enrollment", "course_completed"], "course_name": ["X", "X", "Y", "Y"], "text": [None] * 4, "score": pd.array([60, 80, None, None], dtype="Int64")})
    projects = pd.DataFrame({"project_id": [1, 2], "name": ["P1", "P2"], "team_id": [1, 1], "outcome_status": ["on-time", "delayed"], "outcome_score": [90.0, 50.0]})
    return dict(teams=teams, employees=employees, performance_reviews=reviews, competencies=competencies, competency_assessments=assessments, talent_review=talent, learning_activity=learning, projects=projects)


def test_fact_review_prior_rating_and_trend(mini):
    dim = tg.dim_employee(mini["employees"], mini["teams"])
    f = tg.fact_performance_review(mini["performance_reviews"], dim)
    e1 = f[f["employee_id"] == 1].sort_values("review_period")
    assert list(e1["trend"]) == ["first_review", "improving"] and e1["rating_delta"].iloc[1] == 2
    assert f[f["employee_id"] == 2]["trend"].iloc[1] == "declining"
    assert f["department"].iloc[0] == "Engineering"


def test_skill_gap_severity_and_threshold(mini):
    dim = tg.dim_employee(mini["employees"], mini["teams"])
    g = tg.mart_skill_gap(mini["competency_assessments"], mini["competencies"], dim).set_index("employee_id")
    assert g.loc[1, "gap"] == 2 and g.loc[1, "gap_severity"] == "moderate" and bool(g.loc[1, "critical_gap"])
    # category does NOT matter: Leadership gap of 1 for a manager is not critical at threshold 2
    assert g.loc[2, "gap"] == 1 and g.loc[2, "gap_severity"] == "minor" and not bool(g.loc[2, "critical_gap"])
    assert g.loc[3, "gap"] == 0 and g.loc[3, "gap_severity"] == "none" and g.loc[3, "gap_status"] == "exceeds"
    # threshold is configurable
    g1 = tg.mart_skill_gap(mini["competency_assessments"], mini["competencies"], dim, critical_threshold=1).set_index("employee_id")
    assert bool(g1.loc[2, "critical_gap"]) and (g1["critical_threshold"] == 1).all()
    g3 = tg.mart_skill_gap(mini["competency_assessments"], mini["competencies"], dim, critical_threshold=3)
    assert not g3["critical_gap"].any()


def test_gap_severity_labels():
    assert list(tg.gap_severity(pd.Series([0, 1, 2, 3, 4, 7, -1]))) == ["none", "minor", "moderate", "major", "severe", "severe", "none"]


def test_talent_matrix_nine_box(mini):
    dim = tg.dim_employee(mini["employees"], mini["teams"])
    f = tg.fact_performance_review(mini["performance_reviews"], dim)
    g = tg.mart_skill_gap(mini["competency_assessments"], mini["competencies"], dim)
    t = tg.mart_talent_matrix(f, mini["talent_review"], g, dim).set_index("employee_id")
    assert t.loc[1, "avg_recent_rating"] == 3.0 and t.loc[1, "performance_band"] == "medium"
    assert t.loc[2, "performance_band"] == "high" and t.loc[2, "nine_box"] == "High performance / Low potential"
    assert bool(t.loc[1, "high_potential"]) and bool(t.loc[1, "promotion_ready"]) and not bool(t.loc[1, "ready_and_high_perf"])
    assert t.loc[1, "critical_gaps"] == 1 and t.loc[2, "critical_gaps"] == 0 and len(t) == 3


def test_learning_summary_rates(mini):
    dim = tg.dim_employee(mini["employees"], mini["teams"])
    l = tg.fact_learning_summary(mini["learning_activity"], dim).set_index("employee_id")
    assert l.loc[1, "quiz_attempted"] == 1 and l.loc[1, "quiz_passed"] == 1 and l.loc[1, "quiz_pass_rate"] == 1.0
    assert l.loc[1, "avg_quiz_score"] == 70.0
    assert l.loc[2, "course_completion_rate"] == 1.0 and l.loc[3, "total_events"] == 0
    assert int(l["total_events"].sum()) == 4


def test_attrition_risk_score(mini):
    dim = tg.dim_employee(mini["employees"], mini["teams"])
    f = tg.fact_performance_review(mini["performance_reviews"], dim)
    g = tg.mart_skill_gap(mini["competency_assessments"], mini["competencies"], dim)
    t = tg.mart_talent_matrix(f, mini["talent_review"], g, dim)
    l = tg.fact_learning_summary(mini["learning_activity"], dim)
    r = tg.mart_attrition_risk(t, l, mini["talent_review"], as_of=pd.Timestamp("2026-10-01")).set_index("employee_id")
    # emp1: declared High (+3), improving, latest 4, active learner, Ready Now -> 3 -> Low
    assert r.loc[1, "risk_score"] == 3 and r.loc[1, "risk_level"] == "Medium"
    # emp2: Low (+0), declining (+2), latest 3, inactive >365d (+2), Not Ready & tenure 6 (+1) -> 5 Medium
    assert r.loc[2, "risk_score"] == 5 and r.loc[2, "risk_level"] == "Medium"
    # emp3: Medium (+1), stable, never learned (+2) -> 3
    assert r.loc[3, "risk_score"] == 3 and bool(r.loc[3, "inactive_learner"])


def test_team_performance_aggregates(mini):
    dim = tg.dim_employee(mini["employees"], mini["teams"])
    f = tg.fact_performance_review(mini["performance_reviews"], dim)
    g = tg.mart_skill_gap(mini["competency_assessments"], mini["competencies"], dim)
    t = tg.mart_talent_matrix(f, mini["talent_review"], g, dim)
    tp = tg.mart_team_performance(f, mini["projects"], mini["teams"], t).set_index("team_id")
    assert tp.loc[1, "headcount"] == 2 and tp.loc[1, "avg_rating_all"] == 3.5 and tp.loc[1, "avg_rating_latest"] == 3.5
    assert tp.loc[1, "projects"] == 2 and tp.loc[1, "on_time_share"] == 0.5 and tp.loc[1, "avg_outcome_score"] == 70.0
    assert tp.loc[2, "projects"] == 0 and tp.loc[1, "declining_share"] == 0.5


def test_skill_inventory_grain(mini):
    dim = tg.dim_employee(mini["employees"], mini["teams"])
    g = tg.mart_skill_gap(mini["competency_assessments"], mini["competencies"], dim)
    inv = tg.mart_skill_inventory(g)
    assert not inv.duplicated(["department", "competency_id", "proficiency_level"]).any()
    assert int(inv["employees"].sum()) == 3
