"""End-to-end smoke test on the synthetic sample: Bronze -> Silver -> Gold,
reconciliation across layers, quarantine behaviour and idempotency (run twice).
"""
from __future__ import annotations

import json
import os

import pandas as pd

from acme_common import storage
from acme_common.jobs import run_all, run_bronze, run_silver


def _lake(settings, *parts):
    return storage.join(settings.lake_root, *parts)


def test_full_pipeline_and_reconciliation(settings, sample_dir):
    _, stats = sample_dir
    result = run_all(settings)

    # --- Bronze: every source row landed, malformed JSON preserved ---------
    assert result["bronze"]["employees"] == stats["employees"]
    assert result["bronze"]["performance_reviews"] == stats["reviews"]
    assert result["bronze"]["learning_activity"] == stats["valid"]
    assert result["bronze"]["learning_activity_malformed"] == stats["malformed"]
    assert storage.list_files(_lake(settings, "bronze", "_malformed"), ".csv") or storage.list_files(_lake(settings, "bronze", "_malformed"), ".parquet")

    # --- Silver: quarantine exactly the planted defects --------------------
    s = result["silver"]
    assert s["employees_quarantined"] == 1                         # future hire date
    assert s["performance_reviews_quarantined"] == 1               # rating 9
    assert s["performance_reviews"] == stats["reviews"] - 2        # 1 quarantined + 1 duplicate
    assert s["competency_assessments_quarantined"] == 1            # orphan employee
    assert s["learning_activity_quarantined"] == stats["null_emp"] + stats["bad_date"]
    assert s["learning_activity"] == stats["valid"] - stats["null_emp"] - stats["bad_date"]  # `notes` rows survive

    # --- Gold: grain + aggregates reconcile with Silver --------------------
    g = result["gold"]
    assert g["dim_employee"] == s["employees"] == g["mart_talent_matrix"] == g["mart_attrition_risk"]
    assert g["fact_performance_review"] == s["performance_reviews"]
    learn = storage.read_table(_lake(settings, "gold", "fact_learning_summary"))
    assert int(learn["total_events"].sum()) == s["learning_activity"]
    silver_reviews = storage.read_table(_lake(settings, "silver", "performance_reviews"))
    gold_reviews = storage.read_table(_lake(settings, "gold", "fact_performance_review"))
    assert abs(silver_reviews["rating"].mean() - gold_reviews["rating"].mean()) < 1e-9

    # --- Lineage persisted (file backend) ----------------------------------
    meta = _lake(settings, "_metadata", settings.run_id, "acme-gold-analytics")  # one folder per job
    run = storage.read_json(storage.join(meta, "run.json"))
    assert run["status"] == "SUCCESS" and run["duration_s"] is not None
    edges = [json.loads(l) for l in storage.read_text(storage.join(meta, "edges.jsonl")).splitlines()]
    assert any(e["source_dataset"] == "silver.talent_review" and e["target_dataset"] == "gold.mart_talent_matrix" for e in edges)


def test_rerun_is_idempotent(settings):
    run_bronze(settings)
    first = run_silver(settings)
    run_bronze(settings)  # same RUN_DATE -> same partition
    second = run_silver(settings)
    assert first == second
    emp = storage.read_table(_lake(settings, "silver", "employees"))
    assert emp["employee_id"].is_unique and len(emp) == first["employees"]
    part = _lake(settings, "bronze", "employees", settings.partition())
    assert len([f for f in storage.list_files(part) if not f.endswith("_manifest.json")]) == 1


def test_zero_rows_guard(settings, tmp_path, monkeypatch):
    empty = tmp_path / "empty-sample"
    empty.mkdir()
    for t in ["teams", "competencies", "employees", "projects", "performance_reviews", "competency_assessments", "talent_review"]:
        (empty / f"{t}.csv").write_text("a,b\n")
    monkeypatch.setenv("SAMPLE_DATA_DIR", str(empty))
    monkeypatch.setenv("LEARNING_ACTIVITY_DIR", str(empty))
    from acme_common.config import Settings

    try:
        run_bronze(Settings())
    except RuntimeError as exc:
        assert "zero rows" in str(exc)
    else:  # pragma: no cover
        raise AssertionError("expected zero-rows guard to fail the job")
