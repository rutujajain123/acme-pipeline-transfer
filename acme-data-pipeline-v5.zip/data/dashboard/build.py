#!/usr/bin/env python3
"""Build a minimal static dashboard for the ACME talent pipeline.

Reads the Gold layer (lake) + pipeline metadata, exports the notebooks to
HTML, and writes a single self-contained page to dashboard/site/index.html.

    python3 dashboard/build.py            # uses the same env vars as the jobs
    python3 -m http.server 8080 -d dashboard/site

Buttons on the page:
  - "Open in JupyterLab"  -> live notebook (JUPYTER_URL, default http://localhost:8889)
  - "View notebook"       -> static HTML export, rendered in the page (no kernel needed)
"""
from __future__ import annotations

import html
import json
import os
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
DATA = HERE.parent
sys.path.insert(0, str(DATA))

import pandas as pd  # noqa: E402

from acme_common import storage  # noqa: E402
from acme_common.config import Settings  # noqa: E402

SITE = HERE / "site"
NOTEBOOKS = ["02_business_questions", "03_lineage_and_quality", "01_profiling"]
QUESTIONS = [
    ("Performance ratings & review history", "fact_performance_review"),
    ("Critical skill gaps in key competencies", "mart_skill_gap"),
    ("High-potential employees ready for promotion", "mart_talent_matrix"),
    ("Training & development completed", "fact_learning_summary"),
    ("Employees at risk of attrition", "mart_attrition_risk"),
    ("Performance vs team & project outcomes", "mart_team_performance"),
    ("Distribution of skills across the organization", "mart_skill_inventory"),
]


def gold(s: Settings, table: str) -> pd.DataFrame:
    try:
        return storage.read_table(storage.join(s.lake_root, "gold", table))
    except Exception:  # noqa: BLE001
        return pd.DataFrame()


def latest_runs(s: Settings) -> list[dict]:
    """Latest run per job from Postgres metadata, or the lake's _metadata fallback."""
    try:
        from acme_common import postgres

        df = postgres.read_query(s, f'SELECT * FROM "{s.metadata_schema}".v_latest_runs ORDER BY started_at')
        return df.to_dict("records")
    except Exception:  # noqa: BLE001
        runs = []
        for f in storage.list_files(storage.join(s.lake_root, "_metadata"), "run.json"):
            runs.append(storage.read_json(f))
        latest: dict[str, dict] = {}
        for r in sorted(runs, key=lambda r: r.get("started_at", "")):
            latest[r["job_name"]] = r
        return list(latest.values())


def export_notebooks() -> dict[str, str]:
    out = SITE / "notebooks"
    out.mkdir(parents=True, exist_ok=True)
    done = {}
    for nb in NOTEBOOKS:
        src = DATA / "notebooks" / f"{nb}.ipynb"
        if not src.exists():
            continue
        cmd = [sys.executable, "-m", "jupyter", "nbconvert", "--to", "html", "--output-dir", str(out), str(src)]
        if os.getenv("DASHBOARD_EXECUTE", "false").lower() == "true":
            cmd.insert(5, "--execute")
        r = subprocess.run(cmd, capture_output=True, text=True)
        if r.returncode == 0:
            done[nb] = f"notebooks/{nb}.html"
        else:
            print(f"nbconvert failed for {nb}: {r.stderr[-300:]}", file=sys.stderr)
    return done


def fmt(n) -> str:
    try:
        return f"{int(n):,}"
    except (TypeError, ValueError):
        return "–"


def main() -> int:
    s = Settings()
    SITE.mkdir(parents=True, exist_ok=True)
    jupyter_url = os.getenv("JUPYTER_URL", "http://localhost:8889").rstrip("/")

    rev = gold(s, "fact_performance_review")
    gap = gold(s, "mart_skill_gap")
    tal = gold(s, "mart_talent_matrix")
    risk = gold(s, "mart_attrition_risk")
    learn = gold(s, "fact_learning_summary")
    team = gold(s, "mart_team_performance")

    threshold = int(gap["critical_threshold"].iloc[0]) if "critical_threshold" in gap and len(gap) else s.skill_gap_critical_threshold
    periods = sorted(rev["review_period"].unique()) if len(rev) else []
    avg_by_period = rev.groupby("review_period")["rating"].mean().round(2).to_dict() if len(rev) else {}

    tiles = [
        ("Employees", fmt(tal["employee_id"].nunique() if len(tal) else 0), "in dim_employee"),
        ("Avg rating, latest period", f"{avg_by_period.get(periods[-1], float('nan')):.2f}" if periods else "–",
         f"{periods[-1]} (prev {avg_by_period.get(periods[-2], float('nan')):.2f})" if len(periods) > 1 else ""),
        ("Critical skill gaps", fmt(gap["critical_gap"].sum() if len(gap) else 0),
         f"{fmt(gap.loc[gap['critical_gap'], 'employee_id'].nunique() if len(gap) else 0)} employees · gap ≥ {threshold}"),
        ("Ready now & high performance", fmt(tal["ready_and_high_perf"].sum() if len(tal) else 0),
         f"{fmt(tal['high_potential'].sum() if len(tal) else 0)} high-potential"),
        ("High attrition risk", fmt((risk["risk_level"] == "High").sum() if len(risk) else 0),
         f"{fmt((risk['risk_level'] == 'Medium').sum() if len(risk) else 0)} medium"),
        ("Courses completed", fmt(learn["course_completed"].sum() if len(learn) else 0),
         f"{fmt(learn['certification_earned'].sum() if len(learn) else 0)} certifications"),
    ]

    runs = latest_runs(s)
    nb_html = export_notebooks()
    built = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")

    def tile(label, value, sub):
        return f'<div class="tile"><div class="label">{html.escape(label)}</div><div class="value">{html.escape(str(value))}</div><div class="sub">{html.escape(sub)}</div></div>'

    def run_row(r):
        status = str(r.get("status", ""))
        cls = {"SUCCESS": "ok", "FAILED": "bad"}.get(status, "")
        dur = r.get("duration_s")
        dur = f"{float(dur):.1f}s" if dur not in (None, "") and not pd.isna(dur) else "–"
        return (f'<tr><td>{html.escape(str(r.get("job_name", "")))}</td><td>{html.escape(str(r.get("layer", "")))}</td>'
                f'<td><span class="pill {cls}">{html.escape(status)}</span></td><td>{dur}</td>'
                f'<td>{html.escape(str(r.get("started_at", ""))[:19])}</td></tr>')

    def q_row(i, title, table):
        n = len(gold(s, table))
        return (f'<li><span class="qn">{i}</span><div><div class="qt">{html.escape(title)}</div>'
                f'<div class="qs">{html.escape(table)} · {fmt(n)} rows</div></div>'
                f'<a class="link" href="{jupyter_url}/lab/tree/02_business_questions.ipynb" target="_blank">open ↗</a></li>')

    nb_buttons = "".join(
        f'<button class="btn ghost" data-nb="{path}">{html.escape(nb.split("_", 1)[1].replace("_", " "))}</button>'
        for nb, path in nb_html.items()
    )

    page = f"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>ACME Talent Analytics</title>
<style>
:root{{--bg:#f7f7f8;--card:#ffffff;--ink:#1a1a1a;--ink2:#5c5f66;--ink3:#8a8d94;--line:#e6e7ea;--accent:#2f5bea;--ok:#2ca02c;--bad:#d62728}}
@media (prefers-color-scheme:dark){{:root:not([data-theme=light]){{--bg:#111214;--card:#1b1c1f;--ink:#f2f2f3;--ink2:#b3b6bd;--ink3:#7f838c;--line:#2a2c31;--accent:#7a9bff}}}}
*{{box-sizing:border-box}}body{{margin:0;background:var(--bg);color:var(--ink);font:15px/1.5 -apple-system,BlinkMacSystemFont,"Segoe UI",Inter,Roboto,sans-serif}}
.wrap{{max-width:1100px;margin:0 auto;padding:32px 16px 64px}}
header{{display:flex;justify-content:space-between;align-items:flex-end;gap:16px;flex-wrap:wrap;margin-bottom:28px}}
h1{{font-size:22px;margin:0 0 4px;font-weight:650;letter-spacing:-.01em}}.muted{{color:var(--ink2);font-size:13px}}
.actions{{display:flex;gap:8px;flex-wrap:wrap}}
.btn{{border:1px solid var(--line);background:var(--card);color:var(--ink);padding:9px 14px;border-radius:8px;font:inherit;font-size:14px;cursor:pointer;text-decoration:none;display:inline-flex;align-items:center;gap:6px}}
.btn.primary{{background:var(--accent);border-color:var(--accent);color:#fff}}.btn.ghost{{background:transparent}}.btn[aria-pressed=true]{{border-color:var(--accent);color:var(--accent)}}
.tiles{{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:12px;margin-bottom:28px}}
.tile{{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:14px 16px}}
.label{{font-size:12px;color:var(--ink2);text-transform:uppercase;letter-spacing:.04em}}.value{{font-size:28px;font-weight:650;margin:4px 0 2px;letter-spacing:-.01em}}.sub{{font-size:12px;color:var(--ink3)}}
h2{{font-size:15px;font-weight:650;margin:28px 0 10px;color:var(--ink2)}}
.card{{background:var(--card);border:1px solid var(--line);border-radius:10px;overflow:hidden}}
ol.q{{list-style:none;margin:0;padding:0}}ol.q li{{display:flex;gap:14px;align-items:center;padding:12px 16px;border-top:1px solid var(--line)}}ol.q li:first-child{{border-top:0}}
.qn{{width:26px;height:26px;border-radius:50%;background:var(--bg);border:1px solid var(--line);display:grid;place-items:center;font-size:12px;color:var(--ink2);flex:none}}
.qt{{font-weight:550}}.qs{{font-size:12px;color:var(--ink3)}}ol.q li .link{{margin-left:auto;color:var(--accent);text-decoration:none;font-size:13px;white-space:nowrap}}
table{{width:100%;border-collapse:collapse;font-size:14px}}th,td{{text-align:left;padding:10px 16px;border-top:1px solid var(--line)}}th{{border-top:0;font-size:12px;color:var(--ink2);text-transform:uppercase;letter-spacing:.04em}}
.pill{{font-size:12px;padding:2px 8px;border-radius:999px;border:1px solid var(--line);color:var(--ink2)}}.pill.ok{{color:var(--ok);border-color:var(--ok)}}.pill.bad{{color:var(--bad);border-color:var(--bad)}}
#viewer{{display:none;margin-top:12px}}#viewer iframe{{width:100%;height:85vh;border:1px solid var(--line);border-radius:10px;background:#fff}}
.nbbar{{display:flex;gap:8px;flex-wrap:wrap;align-items:center}}
footer{{margin-top:36px;font-size:12px;color:var(--ink3)}}
</style></head><body>
<div class="wrap">
<header>
  <div><h1>ACME Talent Analytics</h1><div class="muted">Performance · skills · succession · attrition — Gold layer, built {built}</div></div>
  <div class="actions">
    <a class="btn primary" href="{jupyter_url}/lab/tree/02_business_questions.ipynb" target="_blank">Open in JupyterLab ↗</a>
    <button class="btn" id="viewbtn">View notebook</button>
  </div>
</header>

<div class="tiles">{''.join(tile(*t) for t in tiles)}</div>

<section id="viewer">
  <div class="nbbar"><span class="muted">Static export — use “Open in JupyterLab” for the interactive threshold slider.</span>{nb_buttons}
    <button class="btn ghost" id="closebtn">close</button></div>
  <iframe id="nbframe" title="notebook"></iframe>
</section>

<h2>Business questions</h2>
<div class="card"><ol class="q">{''.join(q_row(i + 1, t, tb) for i, (t, tb) in enumerate(QUESTIONS))}</ol></div>

<h2>Pipeline — latest runs</h2>
<div class="card"><table><thead><tr><th>job</th><th>layer</th><th>status</th><th>duration</th><th>started</th></tr></thead>
<tbody>{''.join(run_row(r) for r in runs) or '<tr><td colspan=5 class="muted">no runs recorded yet</td></tr>'}</tbody></table></div>

<footer>Lake: {html.escape(s.lake_root)} · engine: pandas · skill-gap critical threshold: {threshold}</footer>
</div>
<script>
const viewer=document.getElementById('viewer'),frame=document.getElementById('nbframe');
const first={json.dumps(next(iter(nb_html.values()), ""))};
function show(p){{frame.src=p;viewer.style.display='block';document.querySelectorAll('[data-nb]').forEach(b=>b.setAttribute('aria-pressed',b.dataset.nb===p));viewer.scrollIntoView({{behavior:'smooth'}});}}
document.getElementById('viewbtn').onclick=()=>first&&show(first);
document.getElementById('closebtn').onclick=()=>{{viewer.style.display='none';frame.src='';}};
document.querySelectorAll('[data-nb]').forEach(b=>b.onclick=()=>show(b.dataset.nb));
</script>
</body></html>"""
    (SITE / "index.html").write_text(page)
    print(f"wrote {SITE / 'index.html'}  notebooks exported: {list(nb_html)}")
    print(f"serve:  python3 -m http.server 8080 -d {SITE}   ->  http://localhost:8080")
    return 0


if __name__ == "__main__":
    sys.exit(main())
