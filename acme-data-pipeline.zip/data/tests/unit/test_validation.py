"""Schema contract + validator rules (target: 90%+ coverage of validation/)."""
from __future__ import annotations

import pandas as pd
import pytest
from pydantic import ValidationError

from acme_common.validation import SchemaDriftError, dedupe, validate_dataset, validate_rows
from acme_common.validation.models import Employee, LearningEvent, PerformanceReview, TalentReview


def _review(**over):
    base = dict(review_id=1, employee_id=1, review_period="2025-H1", rating=4, manager_comment=None, submitted_date="2025-07-01")
    base.update(over)
    return base


@pytest.mark.parametrize("field,value", [("rating", 0), ("rating", 6), ("review_period", "2025-Q1"), ("submitted_date", "2099-01-01"), ("employee_id", -1)])
def test_review_rejects_bad_values(field, value):
    with pytest.raises(ValidationError):
        PerformanceReview(**_review(**{field: value}))


def test_review_accepts_valid_and_strips_whitespace():
    r = PerformanceReview(**_review(review_period=" 2025-H1 ", manager_comment="  ok "))
    assert r.review_period == "2025-H1" and r.manager_comment == "ok"


def test_employee_future_hire_date_rejected():
    with pytest.raises(ValidationError):
        Employee(employee_id=1, first_name="A", last_name="B", email="a@b.co", team_id=1, job_level="IC1", hire_date="2099-01-01")


def test_employee_bad_job_level_rejected():
    with pytest.raises(ValidationError):
        Employee(employee_id=1, first_name="A", last_name="B", email="a@b.co", team_id=1, job_level="CEO", hire_date="2020-01-01")


def test_talent_review_enums():
    TalentReview(employee_id=1, review_cycle="2025-H1", potential_rating="High", promotion_readiness="Ready Now", attrition_risk="Low")
    with pytest.raises(ValidationError):
        TalentReview(employee_id=1, review_cycle="2025-H1", potential_rating="Very High", promotion_readiness="Ready Now", attrition_risk="Low")


class TestLearningEvent:
    base = dict(event_id="EV0000000001", employee_id="42", event_date="2025-01-01T10:00:00", event_type="quiz_passed", course_name="C", text="t", score=90, year=2025, month=1, day=1)

    def test_string_employee_id_cast_to_int(self):
        assert LearningEvent(**self.base).employee_id == 42

    @pytest.mark.parametrize("emp", [None, "", "abc"])
    def test_null_or_non_numeric_employee_id_rejected(self, emp):
        with pytest.raises(ValidationError):
            LearningEvent(**{**self.base, "employee_id": emp})

    @pytest.mark.parametrize("d", ["", "01/15/2025", "not-a-date"])
    def test_bad_dates_rejected(self, d):
        with pytest.raises(ValidationError):
            LearningEvent(**{**self.base, "event_date": d})

    def test_space_separated_timestamp_accepted(self):
        assert LearningEvent(**{**self.base, "event_date": "2025-01-01 10:00:00"}).event_date.hour == 10

    def test_score_range_and_unknown_type(self):
        with pytest.raises(ValidationError):
            LearningEvent(**{**self.base, "score": 101})
        with pytest.raises(ValidationError):
            LearningEvent(**{**self.base, "event_type": "logged_in"})


def test_validate_rows_splits_valid_and_quarantine():
    df = pd.DataFrame([_review(), _review(review_id=2, rating=9), _review(review_id=3, submitted_date="bad")])
    valid, bad, summary = validate_rows(df, PerformanceReview, "performance_reviews")
    assert len(valid) == 1 and len(bad) == 2
    assert summary.rows_in == 3 and summary.rows_quarantined == 2
    assert "rating" in bad.iloc[0]["error_fields"]
    assert "submitted_date" in bad.iloc[1]["error_reason"]


def test_schema_drift_raises():
    df = pd.DataFrame([{"review_id": 1, "employee_id": 1}])  # missing rating, period, date
    with pytest.raises(SchemaDriftError):
        validate_rows(df, PerformanceReview, "performance_reviews")


def test_dedupe_keeps_latest_by_order():
    df = pd.DataFrame([{"k": 1, "v": "old", "_ingest_ts": "2025-01-01"}, {"k": 1, "v": "new", "_ingest_ts": "2025-02-01"}, {"k": 2, "v": "x", "_ingest_ts": "2025-01-01"}])
    out, dropped = dedupe(df, ["k"], order_by="_ingest_ts")
    assert dropped == 1 and out.loc[out["k"] == 1, "v"].item() == "new"


def test_validate_dataset_enforces_foreign_keys():
    employees = pd.DataFrame([{"employee_id": 1}])
    reviews = pd.DataFrame([_review(employee_id=1), _review(review_id=2, employee_id=999)])
    valid, bad, summary = validate_dataset(reviews, "performance_reviews", parents={"employees": employees}, order_by=None)
    assert len(valid) == 1 and len(bad) == 1
    assert "fk violation" in bad.iloc[0]["error_reason"]
    assert any(c["check"].startswith("fk:employee_id") and not c["passed"] for c in summary.checks)
