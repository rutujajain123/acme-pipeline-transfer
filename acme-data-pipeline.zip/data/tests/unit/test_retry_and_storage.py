"""Error-handling/retry paths and lake storage behaviour (target: 85%+)."""
from __future__ import annotations

import os

import pandas as pd
import pytest

from acme_common import storage
from acme_common.retry import RetryExhausted, retry


def test_retry_succeeds_after_transient_failures():
    calls = {"n": 0}
    sleeps: list[float] = []

    @retry(exceptions=(ConnectionError,), attempts=4, base_delay=1.0, jitter=0.0, sleep=sleeps.append)
    def flaky():
        calls["n"] += 1
        if calls["n"] < 3:
            raise ConnectionError("boom")
        return "ok"

    assert flaky() == "ok" and calls["n"] == 3
    assert sleeps == [1.0, 2.0]  # exponential backoff


def test_retry_exhausts_and_wraps_last_error():
    @retry(exceptions=(ValueError,), attempts=2, base_delay=0.0, jitter=0.0, sleep=lambda _: None)
    def always():
        raise ValueError("nope")

    with pytest.raises(RetryExhausted) as exc:
        always()
    assert isinstance(exc.value.__cause__, ValueError)


def test_retry_does_not_catch_other_exceptions():
    @retry(exceptions=(ValueError,), attempts=3, sleep=lambda _: None)
    def typed():
        raise KeyError("x")

    with pytest.raises(KeyError):
        typed()


def test_write_partition_is_idempotent(tmp_path):
    d = str(tmp_path / "bronze" / "t" / "year=2026" / "month=10" / "day=14")
    storage.write_partition(pd.DataFrame({"a": [1, 2, 3]}), d)
    storage.write_partition(pd.DataFrame({"a": [1, 2]}), d)  # rerun -> overwrite, not append
    df = storage.read_table(str(tmp_path / "bronze" / "t"))
    assert len(df) == 2 and set(df["year"]) == {"2026"} and set(df["day"]) == {"14"}
    assert len(storage.list_files(d)) == 2  # part + manifest
    assert storage.read_json(os.path.join(d, "_manifest.json"))["rows"] == 2


def test_read_table_empty_root(tmp_path):
    assert storage.read_table(str(tmp_path / "missing")).empty


def test_join_and_is_s3():
    assert storage.join("s3://b/p/", "x", "/y") == "s3://b/p/x/y"
    assert storage.is_s3("s3://b") and not storage.is_s3("./lake")


def test_iter_jsonl_lines(tmp_path):
    p = tmp_path / "e.jsonl"
    p.write_text('{"a":1}\n\n{"a":2}\n')
    assert [n for n, _ in storage.iter_jsonl_lines(str(p))] == [1, 2, 3]
