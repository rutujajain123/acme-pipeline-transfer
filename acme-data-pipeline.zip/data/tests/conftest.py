"""Shared fixtures: a synthetic dataset on disk and Settings pointing at a temp lake."""
from __future__ import annotations

import os
import sys

import pytest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from acme_common.config import Settings  # noqa: E402
from tests.fixtures.make_sample import make_sample  # noqa: E402


@pytest.fixture(scope="session")
def sample_dir(tmp_path_factory) -> tuple[str, dict]:
    d = str(tmp_path_factory.mktemp("sample"))
    stats = make_sample(d)
    return d, stats


@pytest.fixture
def settings(tmp_path, sample_dir, monkeypatch) -> Settings:
    sample, _ = sample_dir
    monkeypatch.setenv("IS_LOCAL", "true")
    monkeypatch.setenv("BRONZE_SOURCE", "csv")
    monkeypatch.setenv("SAMPLE_DATA_DIR", sample)
    monkeypatch.setenv("LOCAL_LAKE_DIR", str(tmp_path / "lake"))
    monkeypatch.setenv("LINEAGE_BACKEND", "file")
    monkeypatch.setenv("WRITE_GOLD_TO_POSTGRES", "false")
    monkeypatch.setenv("RUN_DATE", "2026-10-14")
    monkeypatch.setenv("RUN_ID", "test-run")
    return Settings()


def postgres_available() -> bool:
    try:
        from acme_common import postgres

        return postgres.ping(Settings())
    except Exception:  # noqa: BLE001
        return False


requires_postgres = pytest.mark.skipif(
    os.getenv("RUN_INTEGRATION", "false").lower() != "true" or not postgres_available(),
    reason="set RUN_INTEGRATION=true and POSTGRES_* to run integration tests",
)
