"""Generate a small synthetic dataset with the *same shape and quirks* as the
real sample (7 CSVs + partitioned JSONL with malformed lines, `notes`
instead of `text`, null employee_id, bad dates, duplicate rows).

Used by the test-suite and by `bin/run-pipeline.sh --synthetic` for smoke
runs when the real data is not available. Fully deterministic (seeded).
"""
from __future__ import annotations

import json
import os
import random
from datetime import date, datetime, timedelta

DEPARTMENTS = ["Customer Support", "Data & Analytics", "Design", "Engineering", "Finance", "Human Resources", "Marketing", "Operations", "Product", "Sales"]
JOB_LEVELS = ["IC1", "IC2", "IC3", "Senior IC", "Manager", "Senior Manager", "Director"]
CATEGORIES = ["Technical", "Leadership", "Domain"]
EVENT_TYPES = ["enrollment", "module_started", "module_completed", "course_completed", "quiz_attempted", "quiz_passed", "certification_earned"]
COURSES = [f"Course {i:02d}" for i in range(1, 11)]


def _csv(path: str, header: list[str], rows: list[list]) -> None:
    import csv

    with open(path, "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(header)
        w.writerows(rows)


def make_sample(root: str, employees: int = 60, teams: int = 6, seed: int = 7, scale_events: int = 1) -> dict[str, int]:
    rng = random.Random(seed)
    os.makedirs(root, exist_ok=True)
    today = date(2026, 10, 1)

    team_rows = [[i, f"Team {i}", DEPARTMENTS[(i - 1) % len(DEPARTMENTS)]] for i in range(1, teams + 1)]
    _csv(f"{root}/teams.csv", ["team_id", "name", "department"], team_rows)

    comp_rows = [[i, f"Competency {i}", CATEGORIES[(i - 1) % 3]] for i in range(1, 9)]
    _csv(f"{root}/competencies.csv", ["competency_id", "name", "category"], comp_rows)

    emp_rows = []
    for i in range(1, employees + 1):
        hire = today - timedelta(days=rng.randint(100, 4000))
        emp_rows.append([i, f"First{i}", f"Last{i}", f"user{i}@acme.example", rng.randint(1, teams), rng.choice(JOB_LEVELS), hire.isoformat()])
    # one deliberately bad employee row (future hire date) -> quarantine
    emp_rows.append([employees + 1, "Bad", "Row", "bad@acme.example", 1, "IC1", "2099-01-01"])
    _csv(f"{root}/employees.csv", ["employee_id", "first_name", "last_name", "email", "team_id", "job_level", "hire_date"], emp_rows)

    proj_rows = [[i, f"Project {i}", ((i - 1) % teams) + 1, rng.choice(["on-time", "delayed"]), round(rng.uniform(50, 100), 1)] for i in range(1, 9)]
    _csv(f"{root}/projects.csv", ["project_id", "name", "team_id", "outcome_status", "outcome_score"], proj_rows)

    rev_rows, rid = [], 1
    for i in range(1, employees + 1):
        for period, sub in (("2024-H2", "2025-01-15"), ("2025-H1", "2025-07-15")):
            rev_rows.append([rid, i, period, rng.randint(1, 5), rng.choice(["", "Good work", "Needs focus"]), sub])
            rid += 1
    rev_rows.append([rid, 1, "2025-H1", 9, "", "2025-07-15"])  # rating out of range -> quarantine
    rev_rows.append(list(rev_rows[0]))  # exact duplicate -> dedupe
    _csv(f"{root}/performance_reviews.csv", ["review_id", "employee_id", "review_period", "rating", "manager_comment", "submitted_date"], rev_rows)

    ass_rows, aid = [], 1
    for i in range(1, employees + 1):
        for cid in rng.sample(range(1, 9), 3):
            ass_rows.append([aid, i, cid, rng.randint(1, 5), rng.randint(1, 5), "2025-06-01"])
            aid += 1
    ass_rows.append([aid, 9999, 1, 3, 3, "2025-06-01"])  # orphan employee -> FK quarantine
    _csv(f"{root}/competency_assessments.csv", ["assessment_id", "employee_id", "competency_id", "proficiency_level", "required_level", "assessed_date"], ass_rows)

    tal_rows = [[i, "2025-H1", rng.choice(["Low", "Medium", "High"]), rng.choice(["Ready Now", "1-2 Years", "Not Ready"]), rng.choice(["Low", "Medium", "High"])] for i in range(1, employees + 1)]
    _csv(f"{root}/talent_review.csv", ["employee_id", "review_cycle", "potential_rating", "promotion_readiness", "attrition_risk"], tal_rows)

    # learning activity JSONL, partitioned by day, with the documented quirks
    stats = {"valid": 0, "malformed": 0, "notes": 0, "null_emp": 0, "bad_date": 0}
    eid = 1
    start = datetime(2025, 1, 1)
    for d in range(0, 30 * scale_events):
        day = start + timedelta(days=d)
        pdir = f"{root}/learning_activity/year={day:%Y}/month={day:%m}/day={day:%d}"
        os.makedirs(pdir, exist_ok=True)
        lines = []
        for _ in range(rng.randint(5, 12)):
            et = rng.choice(EVENT_TYPES)
            ev = {
                "event_id": f"EV{eid:010d}",
                "employee_id": str(rng.randint(1, employees)),
                "event_date": (day + timedelta(hours=rng.randint(0, 23))).strftime("%Y-%m-%dT%H:%M:%S"),
                "event_type": et,
                "course_name": rng.choice(COURSES),
                "text": f"{et} for course",
                "score": rng.randint(20, 100) if et.startswith("quiz") else None,
            }
            eid += 1
            roll = rng.random()
            if roll < 0.02:
                ev["notes"] = ev.pop("text"); stats["notes"] += 1
            elif roll < 0.035:
                ev["employee_id"] = None; stats["null_emp"] += 1
            elif roll < 0.05:
                ev["event_date"] = rng.choice(["", "01/15/2025", "not-a-date"]); stats["bad_date"] += 1
            lines.append(json.dumps(ev))
            stats["valid"] += 1
        if d % 7 == 3:
            lines.append('{"event_id": "EV_BROKEN", "employee_id": '); stats["malformed"] += 1
        with open(f"{pdir}/events-000.jsonl", "w") as fh:
            fh.write("\n".join(lines) + "\n")
    stats.update({"employees": employees + 1, "teams": teams, "reviews": len(rev_rows), "assessments": len(ass_rows)})
    return stats


if __name__ == "__main__":
    import sys

    out = sys.argv[1] if len(sys.argv) > 1 else "./synthetic-sample"
    scale = int(sys.argv[2]) if len(sys.argv) > 2 else 1
    print(json.dumps(make_sample(out, scale_events=scale), indent=2))
