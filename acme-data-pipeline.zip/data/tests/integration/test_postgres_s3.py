"""Integration tests against real PostgreSQL (and S3 when S3_BUCKET is set).

Run with:  RUN_INTEGRATION=true POSTGRES_HOST=... pytest tests/integration -v
"""
from __future__ import annotations

import os

import pandas as pd
import pytest

from acme_common import postgres, storage
from acme_common.config import Settings
from tests.conftest import requires_postgres


@requires_postgres
def test_metadata_schema_and_run_persistence():
    s = Settings()
    sql = open(os.path.join(os.path.dirname(__file__), "..", "..", "sql", "metadata_schema.sql")).read()
    postgres.execute_script(s, sql)
    from acme_common.lineage import Run

    os.environ["LINEAGE_BACKEND"] = "postgres"
    with Run(Settings(), "it-job", "test") as run:
        run.dataset("test.ds", "s3://x", rows_read=3, rows_written=3)
        run.validation("test.ds", "ok", True)
    rows = postgres.read_query(s, f'SELECT status FROM "{s.metadata_schema}".pipeline_runs WHERE job_name=%s', ("it-job",))
    assert rows["status"].iloc[0] == "SUCCESS"


@requires_postgres
def test_upsert_is_idempotent():
    s = Settings()
    df = pd.DataFrame({"k": [1, 2], "v": ["a", "b"]})
    postgres.upsert_dataframe(s, df, "it_upsert", ["k"], schema="analytics")
    postgres.upsert_dataframe(s, df.assign(v=["a2", "b"]), "it_upsert", ["k"], schema="analytics")
    out = postgres.read_query(s, 'SELECT * FROM analytics.it_upsert ORDER BY k')
    assert len(out) == 2 and out["v"].tolist() == ["a2", "b"]
    postgres.execute_sql(s, "DROP TABLE analytics.it_upsert")


@requires_postgres
def test_read_source_tables_exist():
    s = Settings()
    emp = postgres.read_table(s, "employees")
    assert {"employee_id", "team_id", "hire_date"} <= set(emp.columns) and len(emp) > 0


@pytest.mark.skipif(not os.getenv("S3_BUCKET"), reason="S3_BUCKET not set")
def test_s3_round_trip():
    s = Settings()
    d = storage.join(s.lake_root, "_it", "year=2026", "month=01", "day=01")
    storage.write_partition(pd.DataFrame({"a": [1, 2]}), d)
    assert len(storage.read_table(storage.join(s.lake_root, "_it"))) == 2
    storage.delete_prefix(storage.join(s.lake_root, "_it"))
