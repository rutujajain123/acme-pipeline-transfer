-- Lineage & observability tables written by acme_common.lineage.Run
CREATE SCHEMA IF NOT EXISTS metadata;

CREATE TABLE IF NOT EXISTS metadata.pipeline_runs (
    run_id      TEXT NOT NULL,
    job_name    TEXT NOT NULL,
    layer       TEXT NOT NULL,
    run_date    DATE NOT NULL,
    started_at  TIMESTAMPTZ NOT NULL,
    ended_at    TIMESTAMPTZ,
    duration_s  DOUBLE PRECISION,
    status      TEXT NOT NULL,            -- RUNNING | SUCCESS | FAILED
    error       TEXT,
    PRIMARY KEY (run_id, job_name)
);

CREATE TABLE IF NOT EXISTS metadata.dataset_versions (
    id               BIGSERIAL PRIMARY KEY,
    run_id           TEXT NOT NULL,
    dataset          TEXT NOT NULL,       -- e.g. silver.performance_reviews
    layer            TEXT NOT NULL,
    path             TEXT NOT NULL,       -- lake path of the written partition
    rows_read        BIGINT NOT NULL DEFAULT 0,
    rows_processed   BIGINT NOT NULL DEFAULT 0,
    rows_written     BIGINT NOT NULL DEFAULT 0,
    rows_quarantined BIGINT NOT NULL DEFAULT 0,
    recorded_at      TIMESTAMPTZ NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_dataset_versions_run ON metadata.dataset_versions (run_id);

CREATE TABLE IF NOT EXISTS metadata.lineage_edges (
    id              BIGSERIAL PRIMARY KEY,
    run_id          TEXT NOT NULL,
    source_dataset  TEXT NOT NULL,
    target_dataset  TEXT NOT NULL,
    transformation  TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_lineage_edges_run ON metadata.lineage_edges (run_id);

CREATE TABLE IF NOT EXISTS metadata.validation_results (
    id          BIGSERIAL PRIMARY KEY,
    run_id      TEXT NOT NULL,
    dataset     TEXT NOT NULL,
    check_name  TEXT NOT NULL,
    passed      BOOLEAN NOT NULL,
    failed_rows BIGINT NOT NULL DEFAULT 0,
    message     TEXT,
    recorded_at TIMESTAMPTZ NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_validation_results_run ON metadata.validation_results (run_id);

-- Convenience views for the lineage notebook
CREATE OR REPLACE VIEW metadata.v_latest_runs AS
SELECT DISTINCT ON (job_name) *
FROM metadata.pipeline_runs
ORDER BY job_name, started_at DESC;

CREATE OR REPLACE VIEW metadata.v_latest_lineage AS
SELECT e.*
FROM metadata.lineage_edges e
JOIN metadata.v_latest_runs r ON r.run_id = e.run_id;
