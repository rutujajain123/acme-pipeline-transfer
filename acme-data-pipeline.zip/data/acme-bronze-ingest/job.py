"""acme-bronze-ingest: bronze layer entrypoint.

Run locally:   python job.py            (IS_LOCAL=true, BRONZE_SOURCE=postgres|csv)
Run on EKS:    deployed by bin/deploy-backend.sh via the python-job Helm chart.

All configuration comes from environment variables (see acme_common/config.py).
"""
from __future__ import annotations

import json
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))

from acme_common.config import get_settings  # noqa: E402
from acme_common.jobs import run_bronze  # noqa: E402
from acme_common.log import configure_logging  # noqa: E402


def main() -> int:
    settings = get_settings()
    log = configure_logging("acme-bronze-ingest", settings.run_id, settings.log_level)
    log.info("config: is_local=%s lake_root=%s run_date=%s", settings.is_local, settings.lake_root, settings.run_date)
    try:
        result = run_bronze(settings)
    except Exception as exc:  # noqa: BLE001
        log.error("job failed: %s", exc, exc_info=True)
        return 1
    log.info("job finished: %s", json.dumps(result, default=str))
    return 0


if __name__ == "__main__":
    sys.exit(main())
