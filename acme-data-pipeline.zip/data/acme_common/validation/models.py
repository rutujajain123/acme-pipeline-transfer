"""Pydantic schema contracts for the Silver layer.

One model per conformed table. These are the *explicit* data-quality rules
required at the Silver boundary; the validator applies them row by row and
quarantines anything that fails.

Conventions:
- IDs are integers (JSONL employee_id arrives as a string and is cast here).
- Dates must parse; review/assessment/submission dates cannot be in the future.
- Categorical fields are normalised (trim + canonical case) before checking.
"""
from __future__ import annotations

import re
from datetime import date, datetime
from typing import Literal, Optional

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

Department = Literal[
    "Customer Support", "Data & Analytics", "Design", "Engineering", "Finance",
    "Human Resources", "Marketing", "Operations", "Product", "Sales",
]
JobLevel = Literal["IC1", "IC2", "IC3", "Senior IC", "Manager", "Senior Manager", "Director"]
CompetencyCategory = Literal["Technical", "Leadership", "Domain"]
OutcomeStatus = Literal["on-time", "delayed", "at-risk", "cancelled"]
LowMedHigh = Literal["Low", "Medium", "High"]
PromotionReadiness = Literal["Ready Now", "1-2 Years", "Not Ready"]
EventType = Literal[
    "enrollment", "module_started", "module_completed", "course_completed",
    "quiz_attempted", "quiz_passed", "certification_earned",
]

_REVIEW_PERIOD = re.compile(r"^\d{4}-H[12]$")


def _not_future(v: date, name: str) -> date:
    if v > date.today():
        raise ValueError(f"{name} is in the future: {v}")
    return v


class _Strict(BaseModel):
    """Base: strip whitespace, forbid unexpected columns (schema drift guard)."""

    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid", coerce_numbers_to_str=False)


class Team(_Strict):
    team_id: int = Field(ge=1)
    name: str = Field(min_length=1)
    department: Department


class Competency(_Strict):
    competency_id: int = Field(ge=1)
    name: str = Field(min_length=1)
    category: CompetencyCategory


class Employee(_Strict):
    employee_id: int = Field(ge=1)
    first_name: str = Field(min_length=1)
    last_name: str = Field(min_length=1)
    email: str = Field(pattern=r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
    team_id: int = Field(ge=1)
    job_level: JobLevel
    hire_date: date

    @field_validator("hire_date")
    @classmethod
    def _hire_not_future(cls, v: date) -> date:
        return _not_future(v, "hire_date")


class Project(_Strict):
    project_id: int = Field(ge=1)
    name: str = Field(min_length=1)
    team_id: int = Field(ge=1)
    outcome_status: OutcomeStatus
    outcome_score: float = Field(ge=0)


class PerformanceReview(_Strict):
    review_id: int = Field(ge=1)
    employee_id: int = Field(ge=1)
    review_period: str
    rating: int = Field(ge=1, le=5)
    manager_comment: Optional[str] = None
    submitted_date: date

    @field_validator("review_period")
    @classmethod
    def _period_format(cls, v: str) -> str:
        if not _REVIEW_PERIOD.match(v):
            raise ValueError(f"review_period must look like 2025-H1, got {v!r}")
        return v

    @field_validator("submitted_date")
    @classmethod
    def _submitted_not_future(cls, v: date) -> date:
        return _not_future(v, "submitted_date")


class CompetencyAssessment(_Strict):
    assessment_id: int = Field(ge=1)
    employee_id: int = Field(ge=1)
    competency_id: int = Field(ge=1)
    proficiency_level: int = Field(ge=1, le=5)
    required_level: int = Field(ge=1, le=5)
    assessed_date: date

    @field_validator("assessed_date")
    @classmethod
    def _assessed_not_future(cls, v: date) -> date:
        return _not_future(v, "assessed_date")


class TalentReview(_Strict):
    employee_id: int = Field(ge=1)
    review_cycle: str
    potential_rating: LowMedHigh
    promotion_readiness: PromotionReadiness
    attrition_risk: LowMedHigh

    @field_validator("review_cycle")
    @classmethod
    def _cycle_format(cls, v: str) -> str:
        if not _REVIEW_PERIOD.match(v):
            raise ValueError(f"review_cycle must look like 2025-H1, got {v!r}")
        return v


class LearningEvent(_Strict):
    """Conformed learning-activity event (from the JSONL stream).

    The Bronze -> Silver transform already maps `notes` -> `text` and keeps
    the source partition columns; this model enforces the contract.
    """

    event_id: str = Field(pattern=r"^EV\d{10}$")
    employee_id: int = Field(ge=1)  # string in JSONL -> cast; null -> quarantine
    event_date: datetime
    event_type: EventType
    course_name: str = Field(min_length=1)
    text: Optional[str] = None
    score: Optional[int] = Field(default=None, ge=0, le=100)
    year: int = Field(ge=2000, le=2100)
    month: int = Field(ge=1, le=12)
    day: int = Field(ge=1, le=31)

    @field_validator("employee_id", mode="before")
    @classmethod
    def _employee_id_from_string(cls, v):
        if v is None or (isinstance(v, str) and v.strip() == ""):
            raise ValueError("employee_id is null/blank")
        if isinstance(v, str):
            s = v.strip()
            if not s.isdigit():
                raise ValueError(f"employee_id is not numeric: {v!r}")
            return int(s)
        return v

    @field_validator("event_date", mode="before")
    @classmethod
    def _event_date_parse(cls, v):
        if v is None or (isinstance(v, str) and v.strip() == ""):
            raise ValueError("event_date is blank")
        if isinstance(v, datetime):
            return v
        s = str(v).strip()
        for fmt in ("%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S.%f", "%Y-%m-%d"):
            try:
                return datetime.strptime(s, fmt)
            except ValueError:
                continue
        raise ValueError(f"event_date has a non-standard format: {v!r}")

    @model_validator(mode="after")
    def _score_only_for_quizzes(self) -> "LearningEvent":
        if self.score is not None and self.event_type not in {"quiz_attempted", "quiz_passed"}:
            # Not fatal: keep the row but the validator records a WARN-level check.
            object.__setattr__(self, "_warn", "score present on a non-quiz event")
        return self


SILVER_MODELS: dict[str, type[BaseModel]] = {
    "teams": Team,
    "competencies": Competency,
    "employees": Employee,
    "projects": Project,
    "performance_reviews": PerformanceReview,
    "competency_assessments": CompetencyAssessment,
    "talent_review": TalentReview,
    "learning_activity": LearningEvent,
}

PRIMARY_KEYS: dict[str, list[str]] = {
    "teams": ["team_id"],
    "competencies": ["competency_id"],
    "employees": ["employee_id"],
    "projects": ["project_id"],
    "performance_reviews": ["review_id"],
    "competency_assessments": ["assessment_id"],
    "talent_review": ["employee_id"],
    "learning_activity": ["event_id"],
}

# child table -> (child column, parent table, parent column)
FOREIGN_KEYS: dict[str, list[tuple[str, str, str]]] = {
    "employees": [("team_id", "teams", "team_id")],
    "projects": [("team_id", "teams", "team_id")],
    "performance_reviews": [("employee_id", "employees", "employee_id")],
    "competency_assessments": [
        ("employee_id", "employees", "employee_id"),
        ("competency_id", "competencies", "competency_id"),
    ],
    "talent_review": [("employee_id", "employees", "employee_id")],
    "learning_activity": [("employee_id", "employees", "employee_id")],
}
