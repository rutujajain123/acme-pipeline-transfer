"""DataFrame validation against the Pydantic contracts, with quarantine.

The validator never raises for row-level problems; it splits the input into
(valid, quarantined) and returns a summary the job can log and persist.
Structural problems (missing required columns = schema drift) do raise,
because nothing downstream can be trusted in that case.
"""
from __future__ import annotations

import logging
import math
from dataclasses import dataclass, field
from typing import Any, Iterable

import pandas as pd
from pydantic import BaseModel, ValidationError

from .models import FOREIGN_KEYS, PRIMARY_KEYS, SILVER_MODELS

log = logging.getLogger("acme.validation")


class SchemaDriftError(ValueError):
    """Required columns are missing or unexpected columns appeared."""


@dataclass
class ValidationSummary:
    dataset: str
    rows_in: int
    rows_valid: int
    rows_quarantined: int
    checks: list[dict[str, Any]] = field(default_factory=list)

    def add_check(self, name: str, passed: bool, failed_rows: int = 0, message: str = "") -> None:
        self.checks.append({"check": name, "passed": passed, "failed_rows": failed_rows, "message": message})

    @property
    def all_passed(self) -> bool:
        return all(c["passed"] for c in self.checks)


def _clean_value(v: Any) -> Any:
    """Convert pandas missing markers to None so Pydantic sees nulls."""
    if v is None:
        return None
    if isinstance(v, float) and math.isnan(v):
        return None
    if v is pd.NaT or (hasattr(v, "__class__") and v.__class__.__name__ in {"NAType", "NaTType"}):
        return None
    if hasattr(v, "item") and not isinstance(v, (str, bytes)):  # numpy scalar
        try:
            return v.item()
        except Exception:  # noqa: BLE001
            return v
    return v


def check_required_columns(df: pd.DataFrame, model: type[BaseModel], dataset: str) -> None:
    required = [name for name, f in model.model_fields.items() if f.is_required()]
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise SchemaDriftError(f"{dataset}: missing required columns {missing}; present={list(df.columns)}")


def validate_rows(
    df: pd.DataFrame,
    model: type[BaseModel],
    dataset: str,
    keep_columns: Iterable[str] | None = None,
) -> tuple[pd.DataFrame, pd.DataFrame, ValidationSummary]:
    """Validate each row with `model`.

    Returns (valid_df, quarantine_df, summary). valid_df contains the model's
    fields with coerced types; quarantine_df keeps the raw row plus
    `error_reason` and `error_fields`.
    """
    check_required_columns(df, model, dataset)
    model_fields = set(model.model_fields)
    unexpected = [c for c in df.columns if c not in model_fields and c not in set(keep_columns or [])]
    if unexpected:
        log.warning("%s: ignoring unexpected columns %s", dataset, unexpected)

    valid_rows: list[dict[str, Any]] = []
    bad_rows: list[dict[str, Any]] = []
    for raw in df.to_dict(orient="records"):
        payload = {k: _clean_value(v) for k, v in raw.items() if k in model_fields}
        try:
            obj = model.model_validate(payload)
            valid_rows.append(obj.model_dump())
        except ValidationError as exc:
            errs = exc.errors()
            raw_out = {k: _clean_value(v) for k, v in raw.items()}
            raw_out["error_fields"] = ",".join(sorted({".".join(map(str, e["loc"])) for e in errs}))
            raw_out["error_reason"] = "; ".join(f"{'.'.join(map(str, e['loc']))}: {e['msg']}" for e in errs)[:1000]
            bad_rows.append(raw_out)

    valid_df = pd.DataFrame(valid_rows, columns=list(model.model_fields))
    quarantine_df = pd.DataFrame(bad_rows)
    summary = ValidationSummary(dataset, len(df), len(valid_df), len(quarantine_df))
    summary.add_check(
        "pydantic_contract",
        passed=len(quarantine_df) == 0,
        failed_rows=len(quarantine_df),
        message="" if len(quarantine_df) == 0 else f"{len(quarantine_df)} rows failed {model.__name__}",
    )
    if keep_columns:
        for c in keep_columns:
            if c in df.columns and c not in valid_df.columns:
                valid_df[c] = df.loc[~df.index.isin(quarantine_df.index), c].values
    return valid_df, quarantine_df, summary


def dedupe(
    df: pd.DataFrame, keys: list[str], order_by: str | None = None, summary: ValidationSummary | None = None
) -> tuple[pd.DataFrame, int]:
    """Keep one row per key (latest by `order_by` if given). Returns (df, dropped)."""
    if df.empty:
        return df, 0
    if order_by and order_by in df.columns:
        df = df.sort_values(order_by, kind="stable")
    before = len(df)
    out = df.drop_duplicates(subset=keys, keep="last").reset_index(drop=True)
    dropped = before - len(out)
    if summary is not None:
        summary.add_check("unique_primary_key", dropped == 0, dropped, f"{dropped} duplicate rows removed on {keys}")
    return out, dropped


def check_not_null(df: pd.DataFrame, cols: list[str], summary: ValidationSummary) -> None:
    for c in cols:
        nulls = int(df[c].isna().sum()) if c in df.columns else len(df)
        summary.add_check(f"not_null:{c}", nulls == 0, nulls)


def enforce_foreign_keys(
    df: pd.DataFrame,
    dataset: str,
    parents: dict[str, pd.DataFrame],
    summary: ValidationSummary,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Anti-join each FK against its parent; orphans go to quarantine."""
    if df.empty:
        return df, pd.DataFrame()
    orphan_mask = pd.Series(False, index=df.index)
    reasons = pd.Series("", index=df.index)
    for child_col, parent_table, parent_col in FOREIGN_KEYS.get(dataset, []):
        parent = parents.get(parent_table)
        if parent is None or parent_col not in parent.columns:
            summary.add_check(f"fk:{child_col}->{parent_table}", False, 0, "parent table unavailable")
            continue
        missing = ~df[child_col].isin(set(parent[parent_col].dropna().astype(int)))
        n = int(missing.sum())
        summary.add_check(f"fk:{child_col}->{parent_table}.{parent_col}", n == 0, n)
        reasons[missing] = reasons[missing] + f"fk violation {child_col}->{parent_table}; "
        orphan_mask |= missing
    orphans = df[orphan_mask].copy()
    if not orphans.empty:
        orphans["error_fields"] = "fk"
        orphans["error_reason"] = reasons[orphan_mask].str.strip()
    return df[~orphan_mask].reset_index(drop=True), orphans.reset_index(drop=True)


def validate_dataset(
    df: pd.DataFrame,
    dataset: str,
    parents: dict[str, pd.DataFrame] | None = None,
    order_by: str | None = "_ingest_ts",
) -> tuple[pd.DataFrame, pd.DataFrame, ValidationSummary]:
    """Full Silver validation for one dataset: contract -> dedupe -> FKs.

    Returns (valid, quarantine, summary). The quarantine frame unions row
    failures from every stage, each row carrying error_reason/error_fields.
    """
    model = SILVER_MODELS[dataset]
    valid, bad_contract, summary = validate_rows(df, model, dataset, keep_columns=[order_by] if order_by else None)
    valid, _ = dedupe(valid, PRIMARY_KEYS[dataset], order_by=order_by, summary=summary)
    if order_by and order_by in valid.columns:
        valid = valid.drop(columns=[order_by])
    check_not_null(valid, PRIMARY_KEYS[dataset], summary)
    bad_fk = pd.DataFrame()
    if parents is not None and dataset in FOREIGN_KEYS:
        valid, bad_fk = enforce_foreign_keys(valid, dataset, parents, summary)
    quarantine = pd.concat([f for f in (bad_contract, bad_fk) if not f.empty], ignore_index=True) if (
        not bad_contract.empty or not bad_fk.empty
    ) else pd.DataFrame(columns=list(df.columns) + ["error_fields", "error_reason"])
    summary.rows_valid = len(valid)
    summary.rows_quarantined = len(quarantine)
    return valid, quarantine, summary
