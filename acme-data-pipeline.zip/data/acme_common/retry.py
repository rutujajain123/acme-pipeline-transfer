"""Exponential-backoff retry decorator for transient PostgreSQL / S3 failures."""
from __future__ import annotations

import functools
import logging
import random
import time
from typing import Callable, Iterable, Type, TypeVar

T = TypeVar("T")
log = logging.getLogger("acme.retry")


class RetryExhausted(RuntimeError):
    """Raised when every attempt failed."""


def retry(
    exceptions: Iterable[Type[BaseException]] = (Exception,),
    attempts: int = 4,
    base_delay: float = 0.5,
    max_delay: float = 10.0,
    jitter: float = 0.2,
    sleep: Callable[[float], None] = time.sleep,
) -> Callable[[Callable[..., T]], Callable[..., T]]:
    """Retry a callable on the given exceptions with exponential backoff.

    delay_n = min(max_delay, base_delay * 2**n) + uniform(0, jitter)
    `sleep` is injectable so unit tests run instantly.
    """
    exc_tuple = tuple(exceptions)

    def decorator(fn: Callable[..., T]) -> Callable[..., T]:
        @functools.wraps(fn)
        def wrapper(*args, **kwargs) -> T:
            last_exc: BaseException | None = None
            for n in range(attempts):
                try:
                    return fn(*args, **kwargs)
                except exc_tuple as exc:  # type: ignore[misc]
                    last_exc = exc
                    if n == attempts - 1:
                        break
                    delay = min(max_delay, base_delay * (2**n)) + random.uniform(0, jitter)
                    log.warning(
                        "transient failure in %s (attempt %d/%d): %s; retrying in %.2fs",
                        fn.__name__, n + 1, attempts, exc, delay,
                    )
                    sleep(delay)
            raise RetryExhausted(
                f"{fn.__name__} failed after {attempts} attempts: {last_exc}"
            ) from last_exc

        return wrapper

    return decorator
