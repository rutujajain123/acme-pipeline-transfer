"""Shared utilities for the ACME performance & talent data pipeline.

Modules:
- config:      environment-driven settings (IS_LOCAL, POSTGRES_*, S3_BUCKET, ...)
- log:         structured JSON logging
- retry:       exponential-backoff decorator for transient DB / S3 failures
- storage:     lake path resolution + parquet/jsonl IO (local filesystem or S3)
- postgres:    connection helpers, read_table, upsert_dataframe
- lineage:     run / dataset / validation tracking (Postgres metadata schema)
- validation:  Pydantic contracts + DataFrame validator with quarantine
- transforms:  pure DataFrame -> DataFrame functions for Bronze / Silver / Gold
"""

__version__ = "0.1.0"
