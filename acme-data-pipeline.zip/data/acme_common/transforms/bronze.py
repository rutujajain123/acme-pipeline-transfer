"""Bronze transforms: raw -> raw + ingestion metadata. No cleaning here.

Bronze is immutable and as-received. Every row gets:
- _ingest_ts   : UTC timestamp of this run
- _run_id      : links to metadata.pipeline_runs
- _source      : "postgres" | "csv" | "jsonl"
- _source_file : originating file (jsonl/csv) or table name (postgres)
"""
from __future__ import annotations

import json
from datetime import datetime, timezone
from typing import Iterable

import pandas as pd

LEARNING_COLUMNS = ["event_id", "employee_id", "event_date", "event_type", "course_name", "text", "score"]


def add_ingest_metadata(df: pd.DataFrame, run_id: str, source: str, source_file: str, ingest_ts: datetime | None = None) -> pd.DataFrame:
    """Return a copy with all columns cast to string plus the metadata columns."""
    out = df.astype("string").copy()
    ts = (ingest_ts or datetime.now(timezone.utc)).isoformat()
    out["_ingest_ts"] = ts
    out["_run_id"] = run_id
    out["_source"] = source
    out["_source_file"] = source_file
    return out


def parse_jsonl_lines(
    lines: Iterable[tuple[int, str]], source_file: str
) -> tuple[list[dict], list[dict]]:
    """Parse JSONL lines into (events, malformed).

    Malformed lines are *kept* (raw text + error) so they can be quarantined,
    never silently dropped. Field-level quirks (`notes` instead of `text`,
    null employee_id, odd dates) are preserved here and handled in Silver;
    Bronze's job is only to capture what arrived.
    """
    events: list[dict] = []
    malformed: list[dict] = []
    for lineno, line in lines:
        if not line.strip():
            continue
        try:
            obj = json.loads(line)
            if not isinstance(obj, dict):
                raise ValueError("JSON value is not an object")
        except (json.JSONDecodeError, ValueError) as exc:
            malformed.append(
                {"_source_file": source_file, "_line_no": lineno, "raw_line": line, "error_reason": f"malformed json: {exc}"}
            )
            continue
        row = {c: obj.get(c) for c in LEARNING_COLUMNS}
        # keep any extra keys (e.g. `notes`) in a JSON blob so nothing is lost
        extras = {k: v for k, v in obj.items() if k not in LEARNING_COLUMNS}
        row["_extra_json"] = json.dumps(extras, default=str) if extras else None
        row["_source_file"] = source_file
        row["_line_no"] = lineno
        events.append(row)
    return events, malformed


def partition_from_path(path: str) -> dict[str, str]:
    """Extract year=/month=/day= segments from a path."""
    out: dict[str, str] = {}
    for seg in path.replace("\\", "/").split("/"):
        if "=" in seg:
            k, v = seg.split("=", 1)
            if k in {"year", "month", "day"}:
                out[k] = v
    return out
