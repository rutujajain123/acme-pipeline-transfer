"""Silver transforms: Bronze (strings) -> conformed, typed, deduped tables.

Source-to-target mapping (Bronze -> Silver)
-------------------------------------------
All tables : drop _run_id/_source/_source_file; _ingest_ts used for dedupe order only
employees  : hire_date -> date; email lower-cased; + full_name, tenure_years (derived)
reviews    : submitted_date -> date; rating -> int; + review_year, review_half (derived)
assessments: *_level -> int; assessed_date -> date; + gap = max(required - proficiency, 0)
learning   : notes -> text (39 events); employee_id str -> int (null -> quarantine);
             event_date parsed (blank/non-standard -> quarantine); score -> Int
"""
from __future__ import annotations

import json
from datetime import date

import pandas as pd

BRONZE_META = ["_run_id", "_source", "_source_file", "_line_no", "_extra_json"]


def _strip_strings(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    for c in out.columns:
        if pd.api.types.is_string_dtype(out[c]) or out[c].dtype == object:
            out[c] = out[c].astype("string").str.strip()
    return out


def normalise_bronze(df: pd.DataFrame) -> pd.DataFrame:
    """Common cleaning for every Bronze table before contract validation."""
    out = _strip_strings(df)
    out = out.drop(columns=[c for c in BRONZE_META if c in out.columns])
    # 'nan'/'None'/'' literals that came from string casting become real nulls
    for c in out.columns:
        if pd.api.types.is_string_dtype(out[c]):
            out[c] = out[c].mask(out[c].isin(["", "nan", "None", "NaN", "<NA>"]))
    return out


def prepare_learning_events(df: pd.DataFrame) -> pd.DataFrame:
    """Apply the known JSONL quirks before contract validation.

    - `notes` (in _extra_json) is mapped to `text` when `text` is null
    - partition columns year/month/day are cast to int
    - blank strings become nulls (so the contract reports them cleanly)
    """
    out = _strip_strings(df)
    if "_extra_json" in out.columns:
        def _notes(v):
            if v is None or pd.isna(v):
                return None
            try:
                return json.loads(v).get("notes")
            except Exception:  # noqa: BLE001
                return None
        notes = out["_extra_json"].map(_notes)
        if "text" not in out.columns:
            out["text"] = pd.NA
        out["text"] = out["text"].where(out["text"].notna(), notes)
    out = out.drop(columns=[c for c in BRONZE_META if c in out.columns])
    for c in ("year", "month", "day"):
        if c in out.columns:
            out[c] = pd.to_numeric(out[c], errors="coerce").astype("Int64")
    for c in out.columns:
        if pd.api.types.is_string_dtype(out[c]):
            out[c] = out[c].mask(out[c].isin(["", "nan", "None", "NaN", "<NA>"]))
    return out


def enrich_employees(df: pd.DataFrame, as_of: date | None = None) -> pd.DataFrame:
    out = df.copy()
    as_of = as_of or date.today()
    out["email"] = out["email"].str.lower()
    out["full_name"] = out["first_name"].str.strip() + " " + out["last_name"].str.strip()
    hire = pd.to_datetime(out["hire_date"])
    out["tenure_years"] = ((pd.Timestamp(as_of) - hire).dt.days / 365.25).round(2)
    return out


def enrich_reviews(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    out["review_year"] = out["review_period"].str.slice(0, 4).astype(int)
    out["review_half"] = out["review_period"].str.slice(-2).map({"H1": 1, "H2": 2}).astype(int)
    out["period_order"] = out["review_year"] * 2 + out["review_half"]  # sortable integer
    return out


def enrich_assessments(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    out["gap"] = (out["required_level"] - out["proficiency_level"]).clip(lower=0).astype(int)
    out["gap_status"] = pd.cut(
        out["proficiency_level"] - out["required_level"],
        bins=[-10, -0.5, 0.5, 10],
        labels=["gap", "meets", "exceeds"],
    ).astype(str)
    return out


def enrich_learning(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    out["event_date"] = pd.to_datetime(out["event_date"])
    out["event_day"] = out["event_date"].dt.date
    out["score"] = out["score"].astype("Int64")
    return out


ENRICHERS = {
    "employees": enrich_employees,
    "performance_reviews": enrich_reviews,
    "competency_assessments": enrich_assessments,
    "learning_activity": enrich_learning,
}
