"""Lake storage abstraction: identical API for a local folder and S3.

Lake layout (identical locally and in the cloud):

    <lake_root>/bronze/<table>/year=YYYY/month=MM/day=DD/part-0.parquet
    <lake_root>/bronze/<table>/year=YYYY/month=MM/day=DD/_manifest.json
    <lake_root>/silver/<table>/year=YYYY/month=MM/day=DD/part-0.parquet
    <lake_root>/silver/_quarantine/<table>/year=.../part-0.parquet
    <lake_root>/gold/<table>/part-0.parquet          (full refresh, snapshot)
    <lake_root>/_metadata/...                        (lineage fallback when no DB)

A partition is the unit of idempotency: writing a partition deletes its
previous contents first, so re-running a job for the same RUN_DATE can never
produce duplicate files.
"""
from __future__ import annotations

import glob
import io
import json
import logging
import os
import shutil
from typing import Any, Iterator

import pandas as pd

from .retry import retry

log = logging.getLogger("acme.storage")

try:  # pyarrow is the production parquet engine
    import pyarrow  # noqa: F401

    PARQUET_AVAILABLE = True
except ImportError:  # pragma: no cover - only in stripped-down sandboxes
    PARQUET_AVAILABLE = False
    log.warning("pyarrow not installed: falling back to CSV part files (dev only)")


def is_s3(path: str) -> bool:
    return path.startswith("s3://")


def _split_s3(path: str) -> tuple[str, str]:
    without = path[len("s3://"):]
    bucket, _, key = without.partition("/")
    return bucket, key


def _s3_client():
    import boto3  # imported lazily so local runs don't need boto3

    endpoint = os.getenv("S3_ENDPOINT_URL") or None
    return boto3.client("s3", endpoint_url=endpoint)


def join(*parts: str) -> str:
    cleaned = [p.strip("/") if i else p.rstrip("/") for i, p in enumerate(parts)]
    return "/".join(cleaned)


# --------------------------------------------------------------------------- #
# Generic byte / text IO
# --------------------------------------------------------------------------- #
@retry(attempts=4)
def write_bytes(path: str, data: bytes) -> None:
    if is_s3(path):
        bucket, key = _split_s3(path)
        _s3_client().put_object(Bucket=bucket, Key=key, Body=data)
    else:
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        with open(path, "wb") as fh:
            fh.write(data)


@retry(attempts=4)
def read_bytes(path: str) -> bytes:
    if is_s3(path):
        bucket, key = _split_s3(path)
        return _s3_client().get_object(Bucket=bucket, Key=key)["Body"].read()
    with open(path, "rb") as fh:
        return fh.read()


def write_text(path: str, text: str) -> None:
    write_bytes(path, text.encode("utf-8"))


def read_text(path: str) -> str:
    return read_bytes(path).decode("utf-8")


def write_json(path: str, obj: Any) -> None:
    write_text(path, json.dumps(obj, indent=2, default=str))


def read_json(path: str) -> Any:
    return json.loads(read_text(path))


def size_bytes(path: str) -> int:
    if is_s3(path):
        bucket, key = _split_s3(path)
        return int(_s3_client().head_object(Bucket=bucket, Key=key)["ContentLength"])
    return os.path.getsize(path)


# --------------------------------------------------------------------------- #
# Listing / deletion
# --------------------------------------------------------------------------- #
@retry(attempts=4)
def list_files(root: str, suffix: str = "") -> list[str]:
    """Recursively list files under `root` (local dir or s3 prefix)."""
    if is_s3(root):
        bucket, prefix = _split_s3(root)
        prefix = prefix.rstrip("/") + "/"
        paginator = _s3_client().get_paginator("list_objects_v2")
        keys: list[str] = []
        for page in paginator.paginate(Bucket=bucket, Prefix=prefix):
            for obj in page.get("Contents", []):
                if obj["Key"].endswith(suffix):
                    keys.append(f"s3://{bucket}/{obj['Key']}")
        return sorted(keys)
    if not os.path.isdir(root):
        return []
    pattern = os.path.join(root, "**", f"*{suffix}")
    return sorted(p for p in glob.glob(pattern, recursive=True) if os.path.isfile(p))


def delete_prefix(root: str) -> int:
    """Delete everything under a prefix/dir. Returns the number of objects removed."""
    if is_s3(root):
        files = list_files(root)
        if not files:
            return 0
        bucket, _ = _split_s3(root)
        client = _s3_client()
        for i in range(0, len(files), 1000):
            chunk = [{"Key": _split_s3(f)[1]} for f in files[i : i + 1000]]
            client.delete_objects(Bucket=bucket, Delete={"Objects": chunk})
        return len(files)
    if os.path.isdir(root):
        count = len(list_files(root))
        shutil.rmtree(root)
        return count
    return 0


def exists(path: str) -> bool:
    if is_s3(path):
        return bool(list_files(path)) if not path.endswith("/") else bool(list_files(path))
    return os.path.exists(path)


# --------------------------------------------------------------------------- #
# DataFrame IO
# --------------------------------------------------------------------------- #
_PART_EXT = ".parquet" if PARQUET_AVAILABLE else ".csv"


def _df_to_bytes(df: pd.DataFrame) -> bytes:
    buf = io.BytesIO()
    if PARQUET_AVAILABLE:
        df.to_parquet(buf, index=False, engine="pyarrow")
    else:
        df.to_csv(buf, index=False)
    return buf.getvalue()


def _bytes_to_df(data: bytes, path: str) -> pd.DataFrame:
    buf = io.BytesIO(data)
    if path.endswith(".parquet"):
        return pd.read_parquet(buf, engine="pyarrow")
    return pd.read_csv(buf)


def write_partition(df: pd.DataFrame, partition_dir: str, manifest: dict | None = None) -> str:
    """Overwrite one partition directory with the DataFrame (idempotent).

    Returns the path of the written part file. An optional manifest
    (row count, source size, checksums, ...) is written alongside.
    """
    removed = delete_prefix(partition_dir)
    if removed:
        log.info("overwrote existing partition %s (%d objects removed)", partition_dir, removed)
    part_path = join(partition_dir, f"part-0{_PART_EXT}")
    write_bytes(part_path, _df_to_bytes(df))
    base_manifest = {"rows": int(len(df)), "columns": list(map(str, df.columns)), "part": part_path}
    if manifest:
        base_manifest.update(manifest)
    write_json(join(partition_dir, "_manifest.json"), base_manifest)
    return part_path


def read_table(root: str) -> pd.DataFrame:
    """Read all part files under a table/partition root into one DataFrame.

    Hive partition keys (year=/month=/day=) embedded in the path are added
    as columns, mirroring Spark's behaviour.
    """
    files = [f for f in list_files(root) if f.endswith(_PART_EXT) or f.endswith(".parquet")]
    frames: list[pd.DataFrame] = []
    for f in files:
        df = _bytes_to_df(read_bytes(f), f)
        rel = f[len(root):].strip("/")
        for seg in rel.split("/")[:-1]:
            if "=" in seg:
                k, v = seg.split("=", 1)
                if k not in df.columns:
                    df[k] = v
        frames.append(df)
    if not frames:
        return pd.DataFrame()
    return pd.concat(frames, ignore_index=True)


def iter_jsonl_lines(path: str) -> Iterator[tuple[int, str]]:
    """Yield (line_number, raw_line) for a JSONL file, without parsing."""
    text = read_text(path)
    for i, line in enumerate(text.splitlines(), start=1):
        yield i, line
