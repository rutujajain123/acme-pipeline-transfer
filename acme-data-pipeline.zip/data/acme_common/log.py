"""Structured (JSON) logging shared by every job.

Each line is a single JSON object so `kubectl logs` output can be grepped or
shipped to CloudWatch / OpenSearch without extra parsing. The run_id is
attached to every record so logs can be joined to the lineage tables.
"""
from __future__ import annotations

import json
import logging
import sys
from datetime import datetime, timezone
from typing import Any

_RUN_ID = "unset"
_JOB = "unset"


class JsonFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:  # noqa: D401
        payload: dict[str, Any] = {
            "ts": datetime.now(timezone.utc).isoformat(timespec="milliseconds"),
            "level": record.levelname,
            "logger": record.name,
            "job": _JOB,
            "run_id": _RUN_ID,
            "msg": record.getMessage(),
        }
        extra = getattr(record, "extra_fields", None)
        if extra:
            payload.update(extra)
        if record.exc_info:
            payload["exception"] = self.formatException(record.exc_info)
        return json.dumps(payload, default=str)


def configure_logging(job: str, run_id: str, level: str = "INFO") -> logging.Logger:
    """Install the JSON formatter on the root logger (idempotent)."""
    global _RUN_ID, _JOB
    _RUN_ID, _JOB = run_id, job
    root = logging.getLogger()
    root.setLevel(level.upper())
    for h in list(root.handlers):
        root.removeHandler(h)
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(JsonFormatter())
    root.addHandler(handler)
    return logging.getLogger(job)


def log_event(logger: logging.Logger, level: int, msg: str, **fields: Any) -> None:
    """Log `msg` with arbitrary structured key/value fields."""
    logger.log(level, msg, extra={"extra_fields": fields})


def info(logger: logging.Logger, msg: str, **fields: Any) -> None:
    log_event(logger, logging.INFO, msg, **fields)


def warn(logger: logging.Logger, msg: str, **fields: Any) -> None:
    log_event(logger, logging.WARNING, msg, **fields)


def error(logger: logging.Logger, msg: str, **fields: Any) -> None:
    log_event(logger, logging.ERROR, msg, **fields)
