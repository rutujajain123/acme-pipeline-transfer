"""Data lineage & observability.

Every job wraps its work in a `Run`. The run records:
- job start/end time, duration, exit status
- per dataset: layer, path, rows read / processed / written / quarantined
- lineage edges (input dataset -> output dataset, with the transformation name)
- validation results (check name, passed, failed rows, message)

Backends:
- "postgres": metadata schema (sql/metadata_schema.sql)
- "file":     JSONL files under <lake_root>/_metadata/ (no DB needed)
- "auto":     postgres if reachable, else file
"""
from __future__ import annotations

import json
import logging
import time
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from typing import Any

from . import storage
from .config import Settings

log = logging.getLogger("acme.lineage")


def _now() -> datetime:
    return datetime.now(timezone.utc)


@dataclass
class DatasetRecord:
    run_id: str
    dataset: str
    layer: str
    path: str
    rows_read: int = 0
    rows_processed: int = 0
    rows_written: int = 0
    rows_quarantined: int = 0
    recorded_at: str = field(default_factory=lambda: _now().isoformat())


@dataclass
class EdgeRecord:
    run_id: str
    source_dataset: str
    target_dataset: str
    transformation: str


@dataclass
class ValidationRecord:
    run_id: str
    dataset: str
    check_name: str
    passed: bool
    failed_rows: int
    message: str = ""
    recorded_at: str = field(default_factory=lambda: _now().isoformat())


class Run:
    """Context manager that records a job run and its lineage."""

    def __init__(self, settings: Settings, job_name: str, layer: str):
        self.settings = settings
        self.job_name = job_name
        self.layer = layer
        self.run_id = settings.run_id
        self.started_at = _now()
        self.ended_at: datetime | None = None
        self.status = "RUNNING"
        self.error: str | None = None
        self.datasets: list[DatasetRecord] = []
        self.edges: list[EdgeRecord] = []
        self.validations: list[ValidationRecord] = []
        self._t0 = time.perf_counter()
        self.backend = self._resolve_backend()

    # --- recording ---------------------------------------------------------
    def dataset(self, name: str, path: str, **counts: int) -> DatasetRecord:
        rec = DatasetRecord(self.run_id, name, self.layer, path, **counts)
        self.datasets.append(rec)
        log.info(
            "dataset %s: read=%d processed=%d written=%d quarantined=%d",
            name, rec.rows_read, rec.rows_processed, rec.rows_written, rec.rows_quarantined,
            extra={"extra_fields": asdict(rec)},
        )
        return rec

    def edge(self, source: str, target: str, transformation: str) -> None:
        self.edges.append(EdgeRecord(self.run_id, source, target, transformation))

    def validation(self, dataset: str, check: str, passed: bool, failed_rows: int = 0, message: str = "") -> None:
        rec = ValidationRecord(self.run_id, dataset, check, passed, failed_rows, message)
        self.validations.append(rec)
        (log.info if passed else log.warning)(
            "validation %s/%s: %s (%d failed rows) %s", dataset, check, "PASS" if passed else "FAIL", failed_rows, message
        )

    # --- lifecycle ---------------------------------------------------------
    def __enter__(self) -> "Run":
        log.info("run started: job=%s layer=%s run_id=%s backend=%s", self.job_name, self.layer, self.run_id, self.backend)
        self._persist_run()
        return self

    def __exit__(self, exc_type, exc, tb) -> bool:
        self.ended_at = _now()
        duration = time.perf_counter() - self._t0
        if exc is None:
            self.status = "SUCCESS"
        else:
            self.status = "FAILED"
            self.error = f"{exc_type.__name__}: {exc}"
            log.error("run failed: %s", self.error, exc_info=(exc_type, exc, tb))
        log.info(
            "run finished: status=%s duration_s=%.2f datasets=%d",
            self.status, duration, len(self.datasets),
            extra={"extra_fields": {"status": self.status, "duration_s": round(duration, 3)}},
        )
        try:
            self._persist_all(duration)
        except Exception as pexc:  # noqa: BLE001 - never mask the job's own error
            log.error("could not persist lineage: %s", pexc)
        return False  # re-raise job exceptions

    # --- persistence -------------------------------------------------------
    def _resolve_backend(self) -> str:
        want = self.settings.lineage_backend
        if want in {"postgres", "file"}:
            return want
        try:
            from . import postgres

            return "postgres" if postgres.ping(self.settings) else "file"
        except Exception:  # noqa: BLE001
            return "file"

    def _run_row(self, duration: float | None) -> dict[str, Any]:
        return {
            "run_id": self.run_id,
            "job_name": self.job_name,
            "layer": self.layer,
            "run_date": self.settings.run_date.isoformat(),
            "started_at": self.started_at.isoformat(),
            "ended_at": self.ended_at.isoformat() if self.ended_at else None,
            "duration_s": round(duration, 3) if duration is not None else None,
            "status": self.status,
            "error": self.error,
        }

    def _persist_run(self) -> None:
        if self.backend == "postgres":
            self._pg_upsert_run(None)

    def _persist_all(self, duration: float) -> None:
        if self.backend == "postgres":
            self._pg_upsert_run(duration)
            self._pg_insert_children()
        else:
            root = storage.join(self.settings.lake_root, "_metadata", self.run_id)
            storage.write_json(storage.join(root, "run.json"), self._run_row(duration))
            storage.write_text(storage.join(root, "datasets.jsonl"), _jsonl(self.datasets))
            storage.write_text(storage.join(root, "edges.jsonl"), _jsonl(self.edges))
            storage.write_text(storage.join(root, "validations.jsonl"), _jsonl(self.validations))

    def _pg_upsert_run(self, duration: float | None) -> None:
        from . import postgres

        s = self.settings.metadata_schema
        row = self._run_row(duration)
        postgres.execute_sql(
            self.settings,
            f"""INSERT INTO "{s}".pipeline_runs
                (run_id, job_name, layer, run_date, started_at, ended_at, duration_s, status, error)
                VALUES (%(run_id)s, %(job_name)s, %(layer)s, %(run_date)s, %(started_at)s,
                        %(ended_at)s, %(duration_s)s, %(status)s, %(error)s)
                ON CONFLICT (run_id, job_name) DO UPDATE SET
                    ended_at = EXCLUDED.ended_at, duration_s = EXCLUDED.duration_s,
                    status = EXCLUDED.status, error = EXCLUDED.error""",
            row,
        )

    def _pg_insert_children(self) -> None:
        from . import postgres

        s = self.settings.metadata_schema
        with postgres.connect(self.settings) as conn:
            with conn.cursor() as cur:
                cur.execute(
                    f'DELETE FROM "{s}".dataset_versions WHERE run_id=%s AND layer=%s', (self.run_id, self.layer)
                )
                cur.execute(f'DELETE FROM "{s}".lineage_edges WHERE run_id=%s AND source_dataset IN %s',
                            (self.run_id, tuple(e.source_dataset for e in self.edges) or ("",)))
                cur.execute(f'DELETE FROM "{s}".validation_results WHERE run_id=%s AND dataset IN %s',
                            (self.run_id, tuple(v.dataset for v in self.validations) or ("",)))
                for d in self.datasets:
                    cur.execute(
                        f'INSERT INTO "{s}".dataset_versions (run_id, dataset, layer, path, rows_read, rows_processed, rows_written, rows_quarantined, recorded_at) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s)',
                        (d.run_id, d.dataset, d.layer, d.path, d.rows_read, d.rows_processed, d.rows_written, d.rows_quarantined, d.recorded_at),
                    )
                for e in self.edges:
                    cur.execute(
                        f'INSERT INTO "{s}".lineage_edges (run_id, source_dataset, target_dataset, transformation) VALUES (%s,%s,%s,%s)',
                        (e.run_id, e.source_dataset, e.target_dataset, e.transformation),
                    )
                for v in self.validations:
                    cur.execute(
                        f'INSERT INTO "{s}".validation_results (run_id, dataset, check_name, passed, failed_rows, message, recorded_at) VALUES (%s,%s,%s,%s,%s,%s,%s)',
                        (v.run_id, v.dataset, v.check_name, v.passed, v.failed_rows, v.message, v.recorded_at),
                    )


def _jsonl(records: list) -> str:
    return "\n".join(json.dumps(asdict(r), default=str) for r in records) + ("\n" if records else "")
