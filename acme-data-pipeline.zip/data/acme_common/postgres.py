"""PostgreSQL helpers: connection, table reads, idempotent upserts.

Uses the workshop-injected POSTGRES_* variables. Aurora requires SSL, local
Postgres does not, so `sslmode` is derived from IS_LOCAL (see Settings).
"""
from __future__ import annotations

import logging
from contextlib import contextmanager
from typing import Iterable, Iterator, Sequence

import pandas as pd

from .config import Settings
from .retry import retry

log = logging.getLogger("acme.postgres")


def _psycopg2():
    import psycopg2  # lazy: unit tests don't need a DB driver

    return psycopg2


def _transient_exceptions() -> tuple[type, ...]:
    psycopg2 = _psycopg2()
    return (psycopg2.OperationalError, psycopg2.InterfaceError)


@contextmanager
def connect(settings: Settings) -> Iterator["object"]:
    """Open a connection (with retry/backoff) and commit/rollback on exit."""

    @retry(exceptions=_transient_exceptions(), attempts=5, base_delay=1.0)
    def _open():
        return _psycopg2().connect(
            host=settings.postgres_host,
            port=settings.postgres_port,
            dbname=settings.postgres_name,
            user=settings.postgres_user,
            password=settings.postgres_pass,
            sslmode=settings.sslmode,
            connect_timeout=10,
            application_name="acme-pipeline",
        )

    conn = _open()
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def ping(settings: Settings) -> bool:
    try:
        with connect(settings) as conn:
            with conn.cursor() as cur:
                cur.execute("SELECT 1")
        return True
    except Exception as exc:  # noqa: BLE001
        log.warning("postgres not reachable: %s", exc)
        return False


def execute_sql(settings: Settings, sql: str, params: Sequence | None = None) -> None:
    with connect(settings) as conn:
        with conn.cursor() as cur:
            cur.execute(sql, params)


def execute_script(settings: Settings, sql_text: str) -> None:
    """Run a multi-statement DDL script (e.g. sql/metadata_schema.sql)."""
    with connect(settings) as conn:
        with conn.cursor() as cur:
            cur.execute(sql_text)


def read_table(settings: Settings, table: str, schema: str | None = None) -> pd.DataFrame:
    """Read an entire table as a DataFrame (all columns kept as-is)."""
    schema = schema or settings.source_schema
    with connect(settings) as conn:
        return pd.read_sql_query(f'SELECT * FROM "{schema}"."{table}"', conn)


def read_query(settings: Settings, sql: str, params: Sequence | None = None) -> pd.DataFrame:
    with connect(settings) as conn:
        return pd.read_sql_query(sql, conn, params=params)


def _pg_type(dtype) -> str:
    kind = str(dtype)
    if kind.startswith("int") or kind.startswith("Int"):
        return "BIGINT"
    if kind.startswith("float") or kind.startswith("Float"):
        return "DOUBLE PRECISION"
    if kind.startswith("bool"):
        return "BOOLEAN"
    if "datetime" in kind:
        return "TIMESTAMP"
    return "TEXT"


def upsert_dataframe(
    settings: Settings,
    df: pd.DataFrame,
    table: str,
    keys: Iterable[str],
    schema: str | None = None,
    create: bool = True,
) -> int:
    """Idempotent write: INSERT ... ON CONFLICT (keys) DO UPDATE.

    Running the same Gold job twice leaves exactly one row per key.
    The table is created from the DataFrame dtypes if it does not exist.
    Returns the number of rows sent.
    """
    schema = schema or settings.analytics_schema
    keys = list(keys)
    cols = list(map(str, df.columns))
    missing = [k for k in keys if k not in cols]
    if missing:
        raise ValueError(f"upsert keys {missing} not in DataFrame columns")
    if df.empty:
        log.warning("upsert_dataframe: empty frame for %s.%s, nothing written", schema, table)
        return 0

    col_defs = ", ".join(f'"{c}" {_pg_type(df[c].dtype)}' for c in cols)
    pk = ", ".join(f'"{k}"' for k in keys)
    ddl = (
        f'CREATE SCHEMA IF NOT EXISTS "{schema}"; '
        f'CREATE TABLE IF NOT EXISTS "{schema}"."{table}" ({col_defs}, PRIMARY KEY ({pk}));'
    )
    col_list = ", ".join(f'"{c}"' for c in cols)
    placeholders = ", ".join(["%s"] * len(cols))
    updates = ", ".join(f'"{c}" = EXCLUDED."{c}"' for c in cols if c not in keys) or f'"{keys[0]}" = EXCLUDED."{keys[0]}"'
    sql = (
        f'INSERT INTO "{schema}"."{table}" ({col_list}) VALUES ({placeholders}) '
        f"ON CONFLICT ({pk}) DO UPDATE SET {updates}"
    )
    # NaN/NaT -> NULL for the driver
    records = [
        tuple(None if pd.isna(v) else (v.item() if hasattr(v, "item") else v) for v in row)
        for row in df.itertuples(index=False, name=None)
    ]

    @retry(exceptions=_transient_exceptions(), attempts=4, base_delay=1.0)
    def _write() -> int:
        from psycopg2.extras import execute_batch

        with connect(settings) as conn:
            with conn.cursor() as cur:
                if create:
                    cur.execute(ddl)
                execute_batch(cur, sql, records, page_size=1000)
        return len(records)

    n = _write()
    log.info("upserted %d rows into %s.%s", n, schema, table)
    return n
